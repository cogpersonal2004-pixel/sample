# AEGIS-AI — BP Enterprise AI Operating System

> Autonomous Cyber Defense & IT Operations Brain  
> Hackathon build · v4.2.1

---

## 🚀 Quick Start

```bash
# Option 1 — Open directly (no server needed for basic use)
open index.html

# Option 2 — Recommended: use a local server to avoid CORS issues
npx serve .
# or
python3 -m http.server 3000
# then open http://localhost:3000
```

---

## 📁 Project Structure

```
aegis-ai/
├── index.html              ← Main entry point
│
├── css/
│   ├── variables.css       ← Design tokens (colors, fonts, spacing)
│   ├── base.css            ← Reset + body styles + scan-line effect
│   ├── layout.css          ← Topbar · Sidebar · Shell · Content area
│   ├── components.css      ← All reusable UI components
│   ├── views.css           ← Per-view layout overrides
│   └── animations.css      ← Keyframe animations
│
├── js/
│   ├── data/
│   │   ├── agents.js           ← All 7 agent definitions (models, inputs, JSON schema)
│   │   ├── copilot-responses.js← AI Copilot pre-built response library
│   │   └── scenario-steps.js   ← 8-step E2E incident scenario data
│   │
│   ├── charts/
│   │   ├── canvas-helpers.js   ← Shared: rrect(), getCanvas()
│   │   ├── risk-matrix.js      ← Overview risk quadrant chart
│   │   ├── kill-chain.js       ← Cyber attack kill chain timeline
│   │   ├── temp-forecast.js    ← Compressor bearing temperature forecast
│   │   ├── twin-map.js         ← Digital Twin infrastructure map + simulation
│   │   ├── cluster-chart.js    ← Ticket BERT clustering bubble chart
│   │   ├── arch-layers.js      ← Architecture layer diagram
│   │   ├── event-flow.js       ← Kafka event-driven flow diagram
│   │   ├── interaction-map.js  ← Agent interaction topology graph
│   │   ├── purdue.js           ← Purdue OT/IT model diagram
│   │   ├── scenario-charts.js  ← Signal correlation + phase canvas
│   │   ├── compare-chart.js    ← Competitor comparison bar chart
│   │   ├── decision-boundary.js← Human-AI Tier decision boundary
│   │   ├── tier-gates.js       ← Tier 1/2/3 gate diagram
│   │   └── ticket-flow.js      ← Ticket resolution pipeline
│   │
│   ├── views/
│   │   ├── overview.js         ← EOS Overview view HTML
│   │   ├── agents.js           ← Agent Network view HTML
│   │   ├── interaction.js      ← Agent Interaction Map view HTML
│   │   ├── cyber.js            ← Cyber Defense view HTML
│   │   ├── infra.js            ← Infrastructure view HTML
│   │   ├── ot.js               ← OT/ICS Operations view HTML
│   │   ├── tickets.js          ← Ticket Intelligence view HTML
│   │   ├── compliance.js       ← Compliance & Risk view HTML
│   │   ├── scenario.js         ← E2E Scenario view + Scenario controller
│   │   ├── copilot.js          ← AI Copilot view + Copilot controller
│   │   ├── wow.js              ← Innovation Highlights view HTML
│   │   └── architecture.js     ← Architecture view + Arch tab controller
│   │
│   ├── router.js               ← Maps view names → HTML + chart init
│   └── app.js                  ← Bootstrap · Clock · Nav · Demo · Entry point
│
└── README.md
```

---

## 🧭 Navigation Views

| View | Key Feature |
|---|---|
| ⬡ EOS Overview | Live feed · Risk matrix · ROI · Demo button |
| 🤖 Agent Network | All 7 agents · Click card for JSON schema |
| 🗺️ Agent Interaction Map | Topology graph · Kafka topics · Collaboration patterns |
| 🕸️ Cyber Defense | Kill chain · 4 ML models · MITRE ATT&CK |
| 🔮 Infrastructure | Temp forecast · Digital Twin simulation |
| 🏭 OT / ICS Ops | Purdue model · 5 refinery sites |
| 🧠 Ticket Intelligence | BERT clustering · Processing queue |
| ⚖️ Compliance & Risk | Regulatory matrix · Decision boundary |
| 🎬 E2E Scenario | 8-step animated incident walkthrough |
| 💬 AI Copilot | Working chat with 6 pre-loaded answers |
| 🚀 Innovation Highlights | WOW cards · Competitor comparison |
| 🧱 Architecture | Layers · Stack · Event flow · Zero Trust |

---

## 🛠 Extending / Customising

### Add a new agent
Edit `js/data/agents.js` and add a new entry to the `AGENTS` array.

### Change theme colors
Edit `css/variables.css` — all colors are CSS custom properties.

### Add a new view
1. Create `js/views/myview.js` with `window.renderMyView = function() { return '<html>…'; }`
2. Register it in `js/router.js` under `routes`
3. Add a `<script src="js/views/myview.js">` tag in `index.html`
4. Add a `.nav-item` with `data-view="myview"` in the sidebar

### Add a new chart
1. Create `js/charts/mychart.js` with a `function drawMyChart() { … }` using `getCanvas('myCanvasId')`
2. Add `<script src="js/charts/mychart.js">` in `index.html`
3. Call `drawMyChart()` in your view's `charts` function in `router.js`

---

## 📋 Requirements Coverage

| Original Requirement | Status |
|---|---|
| 7 Sub-agents: Purpose, Inputs, Models, Outputs, Actions | ✅ All 7 fully defined in `js/data/agents.js` |
| Agent Interaction Map | ✅ Dedicated view with topology canvas |
| EOS Control Brain (Master Agent) | ✅ Center node in interaction map + referenced throughout |
| Tier 1/2/3 risk classification | ✅ Decision boundary canvas + tier gates |
| Kafka event-driven architecture | ✅ Event flow diagram + Kafka topic mapping per agent |
| RAG vector memory | ✅ Referenced in all relevant views |
| Digital Twin with simulation | ✅ Interactive simulation buttons in Infrastructure view |
| AI Copilot (voice-enabled queries) | ✅ Working chat in Copilot view |
| Explainable AI | ✅ SHAP mentioned in compliance + copilot responses |
| Zero Trust Architecture | ✅ Purdue model + Zero Trust tab in Architecture |
| SOX, EU AI Act, IEC 62443 | ✅ Compliance view with coverage matrix |
| Innovation Highlights / WOW | ✅ Dedicated view with 6 WOW cards + comparison chart |
| E2E Data Flow Walkthrough | ✅ Animated 8-step scenario with ▶ Play button |
| Business Impact / ROI | ✅ $345M ROI breakdown on Overview |

---

## 🔧 Tech Stack (Frontend only — demo build)

- Vanilla HTML5 + CSS3 + JavaScript (ES6+)
- Canvas 2D API for all charts
- Google Fonts: Syne · IBM Plex Mono · DM Sans
- No external JS libraries or build tools required
