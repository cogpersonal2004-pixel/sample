/* ============================================================
   js/router.js
   Maps view names → HTML builder → chart initializer.
   Called by App.nav() in app.js.
   ============================================================ */

window.Router = (() => {

  /** Map of view id → { html: fn, charts: fn } */
  const routes = {
    overview:     { html: () => window.renderOverview(),      charts: () => { drawRiskCanvas(); } },
    agents:       { html: () => window.renderAgentsView(),    charts: () => {} },
    interaction:  { html: () => window.renderInteractionView(), charts: () => { drawInteractionMap(); } },
    cyber:        { html: () => window.renderCyberView(),     charts: () => { drawKillChain(); } },
    infra:        { html: () => window.renderInfraView(),     charts: () => { drawTempForecast(); drawTwinMap(); } },
    ot:           { html: () => window.renderOTView(),        charts: () => { drawPurdue(); } },
    tickets:      { html: () => window.renderTicketsView(),   charts: () => { drawCluster(); drawTicketFlow(); } },
    compliance:   { html: () => window.renderComplianceView(), charts: () => { drawDecisionBoundary(); } },
    scenario:     { html: () => window.renderScenarioView(),  charts: () => { drawSignalCanvas(); drawPhaseCanvas(); } },
    copilot:      { html: () => window.renderCopilotView(),   charts: () => {} },
    wow:          { html: () => window.renderWowView(),       charts: () => { setTimeout(drawCompareChart, 100); } },
    architecture: { html: () => window.renderArchitectureView(), charts: () => { setTimeout(drawArchLayers, 100); } }
  };

  return {
    /**
     * Navigate to a view.
     * @param {string} viewId
     */
    go(viewId) {
      const route = routes[viewId];
      if (!route) { console.warn(`Router: unknown view "${viewId}"`); return; }

      const content = document.getElementById('content');
      if (!content) return;

      /* Render HTML */
      content.innerHTML = `<div class="view active" id="view-${viewId}">${route.html()}</div>`;

      /* Highlight sidebar item */
      document.querySelectorAll('.nav-item[data-view]').forEach(el => {
        el.classList.toggle('active', el.dataset.view === viewId);
      });

      /* Initialise charts after DOM paint */
      requestAnimationFrame(() => route.charts());
    }
  };
})();
