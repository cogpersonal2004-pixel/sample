/* ============================================================
   js/app.js
   Application bootstrap — clock, navigation, demo mode,
   agent JSON viewer. Entry point loaded last.
   ============================================================ */

window.App = (() => {

  /* ── Clock ── */
  function startClock() {
    function tick() {
      const now = new Date();
      const clk = document.getElementById('clk');
      if (clk) clk.textContent = now.toUTCString().split(' ')[4] + ' UTC';
      const ft = document.getElementById('feed-ts');
      if (ft) ft.textContent = now.getSeconds() + 's ago';
    }
    tick();
    setInterval(tick, 1000);
  }

  /* ── Sidebar navigation ── */
  function bindSidebar() {
    document.querySelectorAll('.nav-item[data-view]').forEach(el => {
      el.addEventListener('click', () => App.nav(el.dataset.view));
    });
  }

  /* ── Demo ── */
  function runDemo() {
    const feed = document.getElementById('alert-feed');
    if (!feed) return;

    const msgs = [
      { s: 'crit', t: '🔴 DEMO: Zero-day exploit on pipeline SCADA bus — CVE-2024-AEGIS-01',      m: 'Cyber Agent · Confidence 99.1% · Tier 1 · CISO approval required · 0.4ms detection' },
      { s: 'info', t: '⚡ EOS Brain: Correlating 14 signals — Cyber + OT + Compliance agents…',   m: 'Cross-domain reasoning · Root cause analysis · Attack path reconstructed in 0.4ms' },
      { s: 'warn', t: '🔒 Action queued: Microsegmentation of SCADA subnet (pending approval)',     m: 'Audit AUD-20241215-9991 created · Zero Trust isolation ready · Twin simulation done' },
      { s: 'ok',   t: '✅ CISO approved · Microsegmentation applied · Threat fully contained',      m: 'Total MTTD+MTTR: 47 seconds · 40 refineries protected · Compliance logged · Memory updated' }
    ];

    let i = 0;
    const iv = setInterval(() => {
      if (i >= msgs.length) { clearInterval(iv); return; }
      const m = msgs[i++];
      const d = document.createElement('div');
      d.className = 'alert-item';
      d.style.animation = 'fadeUp .35s ease';
      d.innerHTML = `<div class="alert-dot ${m.s}"></div>
        <div class="alert-body">
          <div class="alert-title">${m.t}</div>
          <div class="alert-meta">${m.m}</div>
        </div>`;
      feed.insertBefore(d, feed.firstChild);
      if (feed.children.length > 9) feed.removeChild(feed.lastChild);
    }, 1400);
  }

  /* ── Agent JSON viewer ── */
  function showAgentJSON(i) {
    const jv = document.getElementById('agent-json');
    if (jv) jv.innerHTML = window.AGENTS[i].outputJSON;
  }

  /* ── Bootstrap ── */
  function init() {
    startClock();
    bindSidebar();
    Router.go('overview');
  }

  /* Run after all scripts are loaded */
  window.addEventListener('DOMContentLoaded', init);

  /* Public API */
  return {
    nav(viewId)       { Router.go(viewId); },
    runDemo,
    showAgentJSON
  };

})();
