/* js/charts/temp-forecast.js */
function drawTempForecast() {
  const r = getCanvas('tempForecast'); if (!r) return;
  const { ctx, W, H } = r;
  const hist = [62,63,63,64,65,65,66,67,68,69,70,71];
  const pred = [71,73,76,80,85,92,101];
  const total = hist.length + pred.length - 1;
  const minV=57, maxV=114;
  const px = i => 36 + (i/total)*(W-50);
  const py = v => H-20 - ((v-minV)/(maxV-minV))*(H-34);
  [70,80,90,100].forEach(v => {
    ctx.strokeStyle='rgba(255,255,255,.04)'; ctx.lineWidth=.5; ctx.setLineDash([2,4]);
    ctx.beginPath(); ctx.moveTo(36,py(v)); ctx.lineTo(W,py(v)); ctx.stroke();
    ctx.fillStyle='rgba(122,144,187,.35)'; ctx.font='9px IBM Plex Mono,monospace'; ctx.textAlign='right'; ctx.fillText(v+'°',32,py(v)+3);
  });
  ctx.setLineDash([]);
  ctx.strokeStyle='rgba(255,23,68,.3)'; ctx.lineWidth=1; ctx.setLineDash([5,3]);
  ctx.beginPath(); ctx.moveTo(36,py(95)); ctx.lineTo(W-8,py(95)); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle='rgba(255,23,68,.55)'; ctx.font='9px IBM Plex Mono,monospace'; ctx.textAlign='right'; ctx.fillText('FAIL THRESHOLD 95°C',W-10,py(95)-4);
  ctx.beginPath(); ctx.moveTo(px(0),py(hist[0])); hist.forEach((v,i)=>ctx.lineTo(px(i),py(v)));
  ctx.strokeStyle='rgba(0,230,118,.9)'; ctx.lineWidth=2.5; ctx.stroke();
  hist.forEach((v,i)=>{ ctx.beginPath(); ctx.arc(px(i),py(v),3,0,Math.PI*2); ctx.fillStyle='rgba(0,230,118,.8)'; ctx.fill(); });
  ctx.beginPath(); ctx.moveTo(px(hist.length-1),py(hist[hist.length-1])); pred.forEach((v,i)=>ctx.lineTo(px(hist.length+i),py(v)));
  ctx.strokeStyle='rgba(255,196,0,.9)'; ctx.lineWidth=2.5; ctx.setLineDash([7,4]); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle='rgba(0,230,118,.75)'; ctx.font='9px DM Sans,sans-serif'; ctx.textAlign='left'; ctx.fillText('● Actual',38,13);
  ctx.fillStyle='rgba(255,196,0,.8)'; ctx.fillText('● Predicted',96,13);
}
