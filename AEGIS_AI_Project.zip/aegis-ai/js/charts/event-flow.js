/* js/charts/event-flow.js */
function drawEventFlow() {
  const r = getCanvas('eventFlowCanvas'); if (!r) return;
  const { ctx, W, H } = r;

  const nodes = [
    { x:80,  y:H/2, l:'Data Sources', sub:'SCADA·SIEM·ITSM',  col:'rgba(255,196,0,.10)', str:'rgba(255,196,0,.45)' },
    { x:240, y:H/2, l:'Kafka Bus',    sub:'847k events/min',   col:'rgba(0,229,255,.08)', str:'rgba(0,229,255,.45)' },
    { x:400, y:H/2, l:'Flink CEP',    sub:'Real-time corr.',   col:'rgba(0,230,118,.07)', str:'rgba(0,230,118,.38)' },
    { x:570, y:H/2, l:'EOS Brain',    sub:'Decision engine',   col:'rgba(213,0,249,.10)', str:'rgba(213,0,249,.45)' },
    { x:730, y:H/2, l:'7 Agents',     sub:'Autonomous AI',     col:'rgba(0,229,255,.07)', str:'rgba(0,229,255,.38)' }
  ];

  const extras = [
    { x:570, y:70,    l:'RAG Memory',   sub:'Pinecone VDB',      col:'rgba(245,0,87,.08)',  str:'rgba(245,0,87,.32)'  },
    { x:730, y:70,    l:'Actions',      sub:'Auto-remediate',    col:'rgba(0,230,118,.07)', str:'rgba(0,230,118,.32)' },
    { x:730, y:H-60,  l:'Human Review', sub:'Tier 1 & 2 gates',  col:'rgba(255,23,68,.07)', str:'rgba(255,23,68,.28)' }
  ];

  function drawNode(n, w = 130, h = 52) {
    rrect(ctx, n.x-w/2, n.y-h/2, w, h, 8);
    ctx.fillStyle = n.col; ctx.fill();
    ctx.strokeStyle = n.str; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = 'rgba(221,230,255,.85)'; ctx.font = '600 11px Syne,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(n.l, n.x, n.y - 4);
    ctx.fillStyle = 'rgba(122,144,187,.65)'; ctx.font = '9px DM Sans,sans-serif';
    ctx.fillText(n.sub, n.x, n.y + 11);
  }

  /* Main flow arrows */
  for (let i = 0; i < nodes.length - 1; i++) {
    const a = nodes[i], b = nodes[i+1];
    ctx.beginPath(); ctx.moveTo(a.x+66, a.y); ctx.lineTo(b.x-66, b.y);
    ctx.strokeStyle = 'rgba(0,229,255,.25)'; ctx.lineWidth = 1.5; ctx.setLineDash([5,3]); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(0,229,255,.45)'; ctx.font = '11px monospace'; ctx.textAlign = 'center';
    ctx.fillText('→', (a.x+b.x)/2, a.y+4);
  }

  /* Vertical arrows to extra nodes */
  [
    [570, H/2-27, 70+27,   'rgba(245,0,87,.35)' ],
    [730, H/2-27, 70+27,   'rgba(0,230,118,.35)'],
    [730, H/2+27, H-60-27, 'rgba(255,23,68,.3)' ]
  ].forEach(([x, y1, y2, col]) => {
    ctx.beginPath(); ctx.moveTo(x, y1); ctx.lineTo(x, y2);
    ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.setLineDash([3,3]); ctx.stroke(); ctx.setLineDash([]);
  });

  nodes.forEach(n => drawNode(n));
  extras.forEach(n => drawNode(n, 112, 42));
}
