/* js/charts/risk-matrix.js */
function drawRiskCanvas() {
  const r = getCanvas('riskCanvas'); if (!r) return;
  const { ctx, W, H } = r;
  [[ 0,H/2,W/2,H/2,'rgba(0,230,118,.05)'],[W/2,H/2,W/2,H/2,'rgba(255,196,0,.06)'],
   [ 0,  0,W/2,H/2,'rgba(255,100,0,.07)'],[W/2,  0,W/2,H/2,'rgba(255,23,68,.09)']
  ].forEach(z => { ctx.fillStyle = z[4]; ctx.fillRect(z[0], z[1], z[2], z[3]); });
  ctx.strokeStyle = 'rgba(255,255,255,.04)'; ctx.lineWidth = .5;
  ctx.beginPath(); ctx.moveTo(W/2,0); ctx.lineTo(W/2,H); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0,H/2); ctx.lineTo(W,H/2); ctx.stroke();
  [['LOW',36,H-12],['MEDIUM',W/2+18,H-12],['HIGH',36,16],['CRITICAL',W/2+18,16]].forEach((l,i) => {
    ctx.fillStyle = ['rgba(0,230,118,.3)','rgba(255,196,0,.3)','rgba(255,100,0,.35)','rgba(255,23,68,.4)'][i];
    ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'left'; ctx.fillText(l[0],l[1],l[2]);
  });
  ctx.fillStyle = 'rgba(122,144,187,.35)'; ctx.font = '9px DM Sans,sans-serif';
  ctx.textAlign = 'right'; ctx.fillText('IMPACT ↑', W-6, 12); ctx.fillText('PROBABILITY →', W-6, H-4);
  const threats = [
    {x:.78,y:.82,l:'Lateral Movement',c:'#ff1744',r:9},{x:.42,y:.60,l:'Compressor Fail',c:'#ffc400',r:7},
    {x:.55,y:.36,l:'Shadow IT',c:'#ffc400',r:5},{x:.22,y:.26,l:'Config Drift',c:'#00e5ff',r:4},
    {x:.12,y:.14,l:'Expired Certs',c:'#00e676',r:4},{x:.65,y:.72,l:'Insider Threat',c:'#ff1744',r:7},
    {x:.35,y:.47,l:'Log4j Variant',c:'#ff6d00',r:5}
  ];
  threats.forEach(t => {
    const px = t.x*W, py = (1-t.y)*H;
    ctx.beginPath(); ctx.arc(px,py,t.r,0,Math.PI*2); ctx.fillStyle = t.c+'33'; ctx.fill();
    ctx.strokeStyle = t.c; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = t.c; ctx.font = '10px DM Sans,sans-serif'; ctx.textAlign = 'left'; ctx.fillText(t.l, px+t.r+4, py+3);
  });
}
