/* js/charts/purdue.js */
function drawPurdue() {
  const r = getCanvas('purdueCanvas'); if (!r) return;
  const { ctx, W, H } = r;
  const levels = [
    {l:'Level 5 — Enterprise Network (IT)', s:'ERP, Email, Corporate Apps, Cloud', col:'rgba(0,229,255,.07)', str:'rgba(0,229,255,.22)'},
    {l:'Level 4 — Site Business Planning',  s:'Historian, MES, Scheduling, Reporting', col:'rgba(0,230,118,.06)', str:'rgba(0,230,118,.18)'},
    {l:'Level 3 — Site Operations (DMZ)',   s:'SCADA Server, Engineering Workstation', col:'rgba(255,196,0,.06)', str:'rgba(255,196,0,.2)'},
    {l:'Level 2 — Supervisory Control',     s:'HMI, SCADA Front-end, Operator Console', col:'rgba(255,100,0,.07)', str:'rgba(255,100,0,.2)'},
    {l:'Level 1 — Basic Control (PLCs/DCS)',s:'Controllers, Drives, Safety Systems', col:'rgba(255,23,68,.07)', str:'rgba(255,23,68,.18)'},
    {l:'Level 0 — Physical Process',        s:'Sensors, Actuators, Field Devices', col:'rgba(213,0,249,.06)', str:'rgba(213,0,249,.18)'}
  ];
  const lh = (H-14)/levels.length;
  levels.forEach((lv,i)=>{
    const y=7+i*lh;
    rrect(ctx,8,y,W-16,lh-4,6); ctx.fillStyle=lv.col; ctx.fill(); ctx.strokeStyle=lv.str; ctx.lineWidth=.5; ctx.stroke();
    rrect(ctx,8,y,4,lh-4,2); ctx.fillStyle=lv.str; ctx.fill();
    ctx.fillStyle='rgba(221,230,255,.72)'; ctx.font='600 10px Syne,sans-serif'; ctx.textAlign='left'; ctx.fillText(lv.l,20,y+17);
    ctx.fillStyle='rgba(122,144,187,.55)'; ctx.font='9px DM Sans,sans-serif'; ctx.fillText(lv.s,20,y+29);
    ctx.fillStyle='rgba(0,229,255,.6)'; ctx.font='9px IBM Plex Mono,monospace'; ctx.textAlign='right'; ctx.fillText('AEGIS',W-14,y+20);
  });
  const gY = 7+2*lh+lh-4;
  ctx.strokeStyle='rgba(255,23,68,.5)'; ctx.lineWidth=1.5; ctx.setLineDash([6,4]);
  ctx.beginPath(); ctx.moveTo(8,gY+3); ctx.lineTo(W-8,gY+3); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle='rgba(255,23,68,.65)'; ctx.font='9px DM Sans,sans-serif'; ctx.textAlign='center';
  ctx.fillText('⚡ IT/OT Air Gap — Zero Trust Boundary',W/2,gY);
}
