/* js/charts/compare-chart.js */
function drawCompareChart() {
  const r = getCanvas('compareChart'); if (!r) return;
  const { ctx, W, H } = r;

  const caps = ['Ticket Auto-Res','Zero-day Detect','OT/IT Unified','RL Self-Heal','Digital Twin','Predictive MTTF','AI Copilot'];
  const products = [
    { name:'AEGIS-AI',      col:'#00e5ff', vals:[.93,.97,1.0,.99,1.0,.95,1.0] },
    { name:'ServiceNow AI', col:'#00e676', vals:[.55,.30,.15,.20,.00,.25,.40] },
    { name:'Dynatrace',     col:'#ffc400', vals:[.30,.50,.20,.30,.10,.60,.20] },
    { name:'Splunk SIEM',   col:'#f50057', vals:[.20,.65,.25,.10,.00,.20,.15] }
  ];

  const barW    = 12;
  const groupW  = products.length * (barW + 3);
  const cap_w   = (W - 60) / caps.length;

  caps.forEach((cap, ci) => {
    const gx = 50 + ci * cap_w + (cap_w - groupW) / 2;
    products.forEach((p, pi) => {
      const bh = p.vals[ci] * (H - 50);
      const x  = gx + pi*(barW+3), y = H - 24 - bh;
      rrect(ctx, x, y, barW, bh, 3);
      ctx.fillStyle = p.col + (pi === 0 ? 'dd' : '55'); ctx.fill();
    });
    ctx.fillStyle = 'rgba(122,144,187,.55)'; ctx.font = '9px DM Sans,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(cap, 50 + ci*cap_w + cap_w/2, H-6);
  });

  products.forEach((p, i) => {
    ctx.fillStyle = p.col; ctx.fillRect(10, 8+i*16, 10, 8);
    ctx.fillStyle = 'rgba(221,230,255,.7)'; ctx.font = '10px DM Sans,sans-serif'; ctx.textAlign = 'left';
    ctx.fillText(p.name, 24, 16+i*16);
  });
}

/* ─────────────────────────────────────────── */
/* js/charts/decision-boundary.js              */
function drawDecisionBoundary() {
  const r = getCanvas('decisionBoundary'); if (!r) return;
  const { ctx, W, H } = r;

  [
    {y:0,        h:H/3, col:'rgba(255,23,68,.07)',  str:'rgba(255,23,68,.14)',  lbl:'TIER 1 — Human Approval Required',         sub:'Safety-critical · Cyber attacks · OT shutdown'},
    {y:H/3,      h:H/3, col:'rgba(255,196,0,.06)',  str:'rgba(255,196,0,.13)',  lbl:'TIER 2 — AI Recommends, Human Confirms',   sub:'Financial risk · Regulatory · Major changes'},
    {y:H*2/3,    h:H/3, col:'rgba(0,230,118,.05)',  str:'rgba(0,230,118,.11)',  lbl:'TIER 3 — Fully Autonomous',                sub:'Routine · Advisory · Low-risk fixes'}
  ].forEach(z => {
    rrect(ctx, 8, z.y+4, W-16, z.h-8, 8);
    ctx.fillStyle = z.col; ctx.fill(); ctx.strokeStyle = z.str; ctx.lineWidth = .5; ctx.stroke();
    ctx.fillStyle = 'rgba(221,230,255,.78)'; ctx.font = '600 11px Syne,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(z.lbl, W/2, z.y+z.h/2-6);
    ctx.fillStyle = 'rgba(122,144,187,.6)'; ctx.font = '10px DM Sans,sans-serif';
    ctx.fillText(z.sub, W/2, z.y+z.h/2+11);
  });

  [
    {y:H/6,   l:'Cyber attack isolation',  c:'#ff1744'},
    {y:H/4,   l:'OT emergency shutdown',   c:'#ff1744'},
    {y:H/2,   l:'SAP batch job failure',   c:'#ffc400'},
    {y:H*.60, l:'Compliance audit flag',   c:'#ffc400'},
    {y:H*.77, l:'VPN ticket auto-fix',     c:'#00e676'},
    {y:H*.88, l:'Server restart (OOM)',    c:'#00e676'}
  ].forEach(e => {
    ctx.beginPath(); ctx.arc(28, e.y, 5, 0, Math.PI*2); ctx.fillStyle = e.c; ctx.fill();
    ctx.fillStyle = 'rgba(221,230,255,.65)'; ctx.font = '10px DM Sans,sans-serif'; ctx.textAlign = 'left';
    ctx.fillText(e.l, 40, e.y+4);
  });
}

/* ─────────────────────────────────────────── */
/* js/charts/tier-gates.js                     */
function drawTierGates() {
  const r = getCanvas('tierGates'); if (!r) return;
  const { ctx, W, H } = r;

  [
    {y:0,     h:H/3, col:'rgba(255,23,68,.07)',  str:'rgba(255,23,68,.18)',  lbl:'TIER 1 — Human Approval Required',       sub:'Safety-critical / Cyber attack',      act:'🔴 STOP — CISO + CTO must approve'},
    {y:H/3,   h:H/3, col:'rgba(255,196,0,.06)',  str:'rgba(255,196,0,.15)',  lbl:'TIER 2 — AI Recommends, Human Confirms', sub:'Financial / Regulatory Risk',          act:'🟡 HOLD — SRE Lead confirms'},
    {y:H*2/3, h:H/3, col:'rgba(0,230,118,.05)',  str:'rgba(0,230,118,.12)',  lbl:'TIER 3 — Fully Autonomous',              sub:'Advisory / Routine Operations',        act:'🟢 GO — Autonomous execution'}
  ].forEach(z => {
    rrect(ctx, 8, z.y+4, W-16, z.h-8, 8);
    ctx.fillStyle = z.col; ctx.fill(); ctx.strokeStyle = z.str; ctx.lineWidth = .5; ctx.stroke();
    ctx.fillStyle = 'rgba(221,230,255,.82)'; ctx.font = '700 12px Syne,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(z.lbl, W/2, z.y+z.h/2-14);
    ctx.fillStyle = 'rgba(122,144,187,.6)';  ctx.font = '10px DM Sans,sans-serif';
    ctx.fillText(z.sub, W/2, z.y+z.h/2+2);
    ctx.fillStyle = 'rgba(221,230,255,.6)';  ctx.font = '10px IBM Plex Mono,monospace';
    ctx.fillText(z.act, W/2, z.y+z.h/2+18);
  });
}

/* ─────────────────────────────────────────── */
/* js/charts/ticket-flow.js                    */
function drawTicketFlow() {
  const r = getCanvas('ticketFlow'); if (!r) return;
  const { ctx, W, H } = r;

  const steps = ['Ticket Ingested','LLM Classification','RAG Context Pull','EOS Decision','Auto-Resolve / Escalate','Audit + RL Learn'];
  const sw = W / steps.length;

  steps.forEach((s, i) => {
    const x = i*sw + 6, w = sw - 12;
    rrect(ctx, x, 10, w, H-20, 6);
    ctx.fillStyle = `rgba(0,229,255,${.04 + i*.015})`; ctx.fill();
    ctx.strokeStyle = `rgba(0,229,255,${.15 + i*.04})`; ctx.lineWidth = .5; ctx.stroke();
    ctx.fillStyle = 'rgba(221,230,255,.72)'; ctx.font = '10px DM Sans,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(s, x+w/2, H/2+4);
    if (i < steps.length-1) {
      ctx.fillStyle = 'rgba(0,229,255,.45)'; ctx.font = '12px monospace';
      ctx.fillText('→', i*sw+sw-7, H/2+5);
    }
  });
}
