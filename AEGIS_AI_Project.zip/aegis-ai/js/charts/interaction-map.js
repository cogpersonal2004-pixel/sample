/* js/charts/interaction-map.js */
function drawInteractionMap() {
  const r = getCanvas('interactionMap'); if (!r) return;
  const { ctx, W, H } = r;

  const cx = W / 2, cy = H / 2;

  const agentPos = [
    { x: cx,       y: 60,      name: 'Ticket Intel',    icon: '🧠', color: '#00bcd4' },
    { x: cx+220,   y: 120,     name: 'Predictive Infra', icon: '🔮', color: '#00e676' },
    { x: cx+280,   y: H/2,     name: 'Cyber Threat',    icon: '🕸️', color: '#ff1744' },
    { x: cx+180,   y: H-110,   name: 'OT Security',     icon: '🏭', color: '#ffc400' },
    { x: cx-180,   y: H-110,   name: 'Shadow IT',       icon: '🕵️', color: '#f50057' },
    { x: cx-280,   y: H/2,     name: 'Compliance',      icon: '⚖️', color: '#d500f9' },
    { x: cx-220,   y: 120,     name: 'Self-Healing',    icon: '🔄', color: '#00e5ff' }
  ];

  /* Cross-agent collaboration edges */
  const crossEdges = [
    { from: 2, to: 3, col: '#ffc400', label: 'IT/OT crossing' },
    { from: 1, to: 6, col: '#00e5ff', label: 'pre-trigger fix' },
    { from: 0, to: 6, col: '#00e5ff', label: 'trigger runbook' },
    { from: 2, to: 6, col: '#ff1744', label: 'isolation cmd' },
    { from: 4, to: 5, col: '#d500f9', label: 'SOX flag' },
    { from: 1, to: 3, col: '#ffc400', label: 'sensor feed' }
  ];

  crossEdges.forEach(e => {
    const a = agentPos[e.from], b = agentPos[e.to];
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
    ctx.strokeStyle = e.col + '40'; ctx.lineWidth = 1; ctx.setLineDash([4,4]); ctx.stroke(); ctx.setLineDash([]);
    const mx = (a.x+b.x)/2, my = (a.y+b.y)/2;
    ctx.fillStyle = e.col + '80'; ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'center';
    ctx.fillText(e.label, mx, my-4);
  });

  /* EOS → agent spokes */
  agentPos.forEach(ap => {
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ap.x, ap.y);
    ctx.strokeStyle = ap.color + '55'; ctx.lineWidth = 1.5; ctx.setLineDash([3,3]); ctx.stroke(); ctx.setLineDash([]);
    const angle = Math.atan2(ap.y - cy, ap.x - cx);
    const endX = ap.x - Math.cos(angle)*36, endY = ap.y - Math.sin(angle)*36;
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(endX - 8*Math.cos(angle-0.4), endY - 8*Math.sin(angle-0.4));
    ctx.lineTo(endX - 8*Math.cos(angle+0.4), endY - 8*Math.sin(angle+0.4));
    ctx.closePath(); ctx.fillStyle = ap.color + '70'; ctx.fill();
  });

  /* Kafka bus ring */
  ctx.beginPath(); ctx.arc(cx, cy, 120, 0, Math.PI*2);
  ctx.strokeStyle = 'rgba(0,229,255,.1)'; ctx.lineWidth = 1; ctx.setLineDash([6,6]); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = 'rgba(0,229,255,.04)'; ctx.fill();
  ctx.fillStyle = 'rgba(0,229,255,.35)'; ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'center';
  ctx.fillText('KAFKA EVENT BUS', cx, cy+125);

  /* EOS Brain node */
  rrect(ctx, cx-60, cy-38, 120, 76, 12);
  ctx.fillStyle = 'rgba(0,229,255,.1)'; ctx.fill();
  ctx.strokeStyle = 'rgba(0,229,255,.5)'; ctx.lineWidth = 1.5; ctx.stroke();
  ctx.fillStyle = '#00e5ff'; ctx.font = '700 12px Syne,sans-serif'; ctx.textAlign = 'center';
  ctx.fillText('EOS BRAIN', cx, cy-10);
  ctx.fillStyle = 'rgba(0,229,255,.65)'; ctx.font = '9px IBM Plex Mono,monospace';
  ctx.fillText('MASTER AGENT', cx, cy+5);
  ctx.fillStyle = 'rgba(0,229,255,.45)'; ctx.font = '9px DM Sans,sans-serif';
  ctx.fillText('CTO · CISO · SRE', cx, cy+20);

  /* Agent nodes */
  agentPos.forEach(ap => {
    ctx.beginPath(); ctx.arc(ap.x, ap.y, 30, 0, Math.PI*2);
    ctx.fillStyle = ap.color + '12'; ctx.fill();
    ctx.strokeStyle = ap.color + '60'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.font = '16px serif'; ctx.textAlign = 'center'; ctx.fillText(ap.icon, ap.x, ap.y+4);
    ctx.fillStyle = ap.color + 'cc'; ctx.font = '9px DM Sans,sans-serif'; ctx.fillText(ap.name, ap.x, ap.y+44);
  });

  ctx.fillStyle = 'rgba(122,144,187,.4)'; ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'left';
  ctx.fillText('Dashed line = Kafka pub/sub · Solid arrow = direct API call', 14, H-10);
}
