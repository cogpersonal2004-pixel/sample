/* js/charts/twin-map.js */
window.twinState = { compressor: false, network: false, scada: false };

function drawTwinMap() {
  const r = getCanvas('twinMap'); if (!r) return;
  const { ctx, W, H } = r;
  const s = window.twinState;
  const nodes = [
    {x:70, y:70, l:'AWS EKS',    status: s.network?'fail':'ok'},
    {x:190,y:70, l:'Azure AKS',  status: s.network?'fail':'ok'},
    {x:310,y:70, l:'SAP HANA',   status:'ok'},
    {x:380,y:140,l:'ServiceNow', status:'ok'},
    {x:130,y:150,l:'TX Refinery',status: s.compressor?'fail':'warn'},
    {x:255,y:150,l:'SCADA Hub',  status: s.scada?'fail':'warn'},
    {x:60, y:160,l:'Backup DC',  status:'ok'},
    {x:370,y:50, l:'Core Net',   status: s.network?'fail':'ok'}
  ];
  const edges = [[0,4],[1,4],[2,7],[3,7],[4,5],[5,2],[0,6]];
  ctx.setLineDash([3,3]);
  edges.forEach(([a,b]) => {
    const na=nodes[a],nb=nodes[b];
    ctx.beginPath(); ctx.moveTo(na.x,na.y); ctx.lineTo(nb.x,nb.y);
    ctx.strokeStyle=(na.status==='fail'||nb.status==='fail')?'rgba(255,23,68,.3)':'rgba(255,255,255,.06)';
    ctx.lineWidth=1; ctx.stroke();
  });
  ctx.setLineDash([]);
  const C = {ok:['rgba(0,230,118,.1)','rgba(0,230,118,.5)','rgba(0,230,118,.85)'],
              warn:['rgba(255,196,0,.1)','rgba(255,196,0,.7)','rgba(255,196,0,.9)'],
              fail:['rgba(255,23,68,.15)','rgba(255,23,68,.8)','#ff1744']};
  nodes.forEach(n => {
    const col = C[n.status];
    ctx.beginPath(); ctx.arc(n.x,n.y,16,0,Math.PI*2); ctx.fillStyle=col[0]; ctx.fill();
    ctx.strokeStyle=col[1]; ctx.lineWidth=1.5; ctx.stroke();
    ctx.fillStyle=col[2]; ctx.font='9px DM Sans,sans-serif'; ctx.textAlign='center'; ctx.fillText(n.l,n.x,n.y+28);
  });
  if (Object.values(s).some(v=>v)) {
    ctx.fillStyle='rgba(255,23,68,.7)'; ctx.font='10px IBM Plex Mono,monospace'; ctx.textAlign='center';
    ctx.fillText('⚠ SIMULATION ACTIVE — No real-world impact',W/2,H-5);
  }
}

function simulateFailure(type) {
  window.twinState[type] = true;
  drawTwinMap();
  const msgs = {
    compressor:'⚡ Sim: Compressor KZ-007 bearing cascade → 6h downtime → preventive maintenance triggered → $4.2M loss prevented',
    network:'🌐 Sim: Core network partition → AKS nodes isolated → auto-failover to Backup DC → RTO: 8 minutes',
    scada:'🏭 Sim: SCADA overload → HMI unresponsive → OT Agent initiates safe state → process suspended safely'
  };
  const el = document.getElementById('twin-result');
  if (el) el.innerHTML = `<div style="padding:8px;background:rgba(255,23,68,.06);border:1px solid rgba(255,23,68,.2);border-radius:6px;color:var(--amber);font-size:10px">${msgs[type]}</div>`;
}

function resetTwin() {
  window.twinState.compressor = window.twinState.network = window.twinState.scada = false;
  drawTwinMap();
  const el = document.getElementById('twin-result'); if (el) el.innerHTML = '';
}
