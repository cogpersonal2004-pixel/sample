/* js/charts/scenario-charts.js */

function drawSignalCanvas(activeStep = -1) {
  const r = getCanvas('signalCanvas'); if (!r) return;
  const { ctx, W, H } = r;

  const signals = [
    { name: 'GNN Anomaly Score',   color: '#ff1744', data: [.10,.12,.15,.18,.90,.95,.97,.97] },
    { name: 'OT Sensor Deviation', color: '#ffc400', data: [.20,.21,.22,.25,.28,.30,.31,.32] },
    { name: 'UEBA Risk Score',     color: '#d500f9', data: [.05,.07,.10,.80,.88,.91,.93,.94] },
    { name: 'Compliance Audit',    color: '#00e676', data: [  0,  0,  0,  0,  0, .5,  1,  1] }
  ];

  const activeX = activeStep >= 0 ? 40 + (activeStep / 7) * (W - 60) : -1;

  signals.forEach((sig, si) => {
    const y0 = 30 + si * 60;
    ctx.fillStyle = 'rgba(122,144,187,.5)'; ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'left';
    ctx.fillText(sig.name, 10, y0 - 4);
    ctx.fillStyle = 'rgba(255,255,255,.04)'; ctx.fillRect(40, y0, W-60, 36);
    ctx.strokeStyle = sig.color + '30'; ctx.lineWidth = .5; ctx.strokeRect(40, y0, W-60, 36);

    ctx.beginPath();
    sig.data.forEach((v, i) => {
      const x = 40 + (i/7)*(W-60), y = y0 + 36 - v*32;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.strokeStyle = sig.color + (activeStep >= 0 ? 'cc' : '55');
    ctx.lineWidth = 2; ctx.stroke();

    sig.data.forEach((v, i) => {
      if (i <= activeStep || activeStep < 0) {
        ctx.beginPath(); ctx.arc(40+(i/7)*(W-60), y0+36-v*32, 3, 0, Math.PI*2);
        ctx.fillStyle = sig.color; ctx.fill();
      }
    });
  });

  if (activeX > 0) {
    ctx.strokeStyle = 'rgba(0,229,255,.3)'; ctx.lineWidth = 1; ctx.setLineDash([3,3]);
    ctx.beginPath(); ctx.moveTo(activeX, 20); ctx.lineTo(activeX, H-10); ctx.stroke(); ctx.setLineDash([]);
  }
}

function drawPhaseCanvas() {
  const r = getCanvas('phaseCanvas'); if (!r) return;
  const { ctx, W, H } = r;

  const phases   = ['Detect','Correlate','Classify','Contain','Recover','Learn'];
  const agentMap = [['Cyber'],['EOS','OT'],['Compliance','EOS'],['Self-Heal'],['Ticket'],['All Agents']];
  const colors   = ['#ff1744','#00e5ff','#d500f9','#ffc400','#00bcd4','#00e676'];
  const sw = W / phases.length;

  phases.forEach((p, i) => {
    rrect(ctx, i*sw+4, 8, sw-8, H-16, 6);
    ctx.fillStyle = colors[i] + '12'; ctx.fill();
    ctx.strokeStyle = colors[i] + '35'; ctx.lineWidth = .5; ctx.stroke();
    ctx.fillStyle = colors[i] + 'cc'; ctx.font = '600 10px Syne,sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(p, i*sw+sw/2, H/2-6);
    ctx.fillStyle = 'rgba(122,144,187,.65)'; ctx.font = '9px DM Sans,sans-serif';
    ctx.fillText(agentMap[i].join(', '), i*sw+sw/2, H/2+9);
  });
}
