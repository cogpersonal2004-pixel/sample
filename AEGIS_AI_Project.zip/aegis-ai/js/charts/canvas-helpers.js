/* ============================================================
   js/charts/canvas-helpers.js
   Shared canvas drawing utilities used by all chart modules.
   ============================================================ */

/**
 * Draw a rounded rectangle path on a canvas context.
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x  @param {number} y
 * @param {number} w  @param {number} h
 * @param {number} r  corner radius
 */
function rrect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y,     x + w, y + r,     r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x,     y + h, x,     y + h - r, r);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x,     y,     x + r, y,         r);
  ctx.closePath();
}

/**
 * Get a canvas element and clear it.
 * Returns null if the element is not found (view not rendered yet).
 * @param {string} id
 * @returns {{ c: HTMLCanvasElement, ctx: CanvasRenderingContext2D, W: number, H: number } | null}
 */
function getCanvas(id) {
  const c = document.getElementById(id);
  if (!c) return null;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  return { c, ctx, W: c.width, H: c.height };
}
