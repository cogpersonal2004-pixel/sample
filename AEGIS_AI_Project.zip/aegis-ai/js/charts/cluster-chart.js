/* js/charts/cluster-chart.js */
function drawCluster() {
  const r = getCanvas('clusterChart'); if (!r) return;
  const { ctx, W, H } = r;
  [{x:90,y:90,r:52,l:'VPN/Network',p:'42%',col:'rgba(0,229,255,.18)',str:'rgba(0,229,255,.5)'},
   {x:228,y:68,r:38,l:'SAP Access',p:'18%',col:'rgba(0,230,118,.14)',str:'rgba(0,230,118,.45)'},
   {x:324,y:108,r:44,l:'Password',p:'22%',col:'rgba(255,196,0,.14)',str:'rgba(255,196,0,.45)'},
   {x:186,y:158,r:27,l:'HW Fault',p:'10%',col:'rgba(255,23,68,.1)',str:'rgba(255,23,68,.38)'},
   {x:372,y:62,r:21,l:'Other',p:'8%',col:'rgba(122,144,187,.1)',str:'rgba(122,144,187,.3)'}
  ].forEach(cl=>{
    ctx.beginPath(); ctx.arc(cl.x,cl.y,cl.r,0,Math.PI*2); ctx.fillStyle=cl.col; ctx.fill();
    ctx.strokeStyle=cl.str; ctx.lineWidth=1.5; ctx.stroke();
    ctx.fillStyle='rgba(221,230,255,.85)'; ctx.font='600 10px DM Sans,sans-serif'; ctx.textAlign='center';
    ctx.fillText(cl.l,cl.x,cl.y-3); ctx.fillStyle='rgba(221,230,255,.65)'; ctx.font='11px IBM Plex Mono,monospace'; ctx.fillText(cl.p,cl.x,cl.y+12);
  });
  ctx.fillStyle='rgba(122,144,187,.4)'; ctx.font='9px DM Sans,sans-serif'; ctx.textAlign='left';
  ctx.fillText('Bubble size = ticket volume · BERT embeddings + k-means',10,H-5);
}
