/* js/charts/kill-chain.js */
function drawKillChain() {
  const r = getCanvas('killchain'); if (!r) return;
  const { ctx, W, H } = r;
  const stages = ['Recon','Phishing','Initial Access','Lateral Move','OT Target'];
  const activeIdx = 3, step = (W-60)/(stages.length-1);
  stages.forEach((s,i) => {
    const x = 30+i*step, y = H/2-8, done = i<=activeIdx;
    if (i < stages.length-1) {
      ctx.beginPath(); ctx.moveTo(x+22,y); ctx.lineTo(x+step-22,y);
      ctx.strokeStyle = done?'rgba(255,23,68,.6)':'rgba(255,255,255,.06)'; ctx.lineWidth=1.5; ctx.setLineDash([5,3]); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.beginPath(); ctx.arc(x,y,20,0,Math.PI*2);
    ctx.fillStyle = done?'rgba(255,23,68,.15)':'rgba(255,255,255,.02)'; ctx.fill();
    ctx.strokeStyle = done?'#ff1744':'rgba(255,255,255,.08)'; ctx.lineWidth = done?2:1; ctx.stroke();
    ctx.fillStyle = done?'#ff6b6b':'rgba(122,144,187,.4)';
    ctx.font = `${done?'600':'400'} 9px DM Sans,sans-serif`; ctx.textAlign='center'; ctx.fillText(s,x,y+3);
    if (i===activeIdx) { ctx.fillStyle='rgba(255,23,68,.8)'; ctx.font='9px DM Sans,sans-serif'; ctx.fillText('▲ NOW',x,y+34); }
  });
}
