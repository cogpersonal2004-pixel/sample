/* js/charts/arch-layers.js */
function drawArchLayers() {
  const r = getCanvas('archLayers'); if (!r) return;
  const { ctx, W, H } = r;
  const layers = [
    {l:'ACTION LAYER',           sub:'Self-Healing · ServiceNow · SAP PM · Kubernetes Operators · Runbook Automation · PagerDuty',col:'rgba(0,229,255,.07)',str:'rgba(0,229,255,.2)',lc:'#00e5ff'},
    {l:'INTELLIGENCE LAYER',     sub:'EOS Control Brain · 7 AI Agents · LLM Reasoning · RAG Memory (Pinecone) · RL · SHAP',      col:'rgba(213,0,249,.07)',str:'rgba(213,0,249,.2)',lc:'#d500f9'},
    {l:'STREAM PROCESSING LAYER',sub:'Apache Kafka 847k/min · Flink CEP · Real-time Correlation · Event-Driven Mesh',            col:'rgba(0,230,118,.06)',str:'rgba(0,230,118,.18)',lc:'#00e676'},
    {l:'PERCEPTION LAYER',       sub:'SCADA · SIEM · Prometheus · ServiceNow · SAP · Cloud Telemetry (AWS+Azure) · OSIsoft PI',  col:'rgba(255,196,0,.06)',str:'rgba(255,196,0,.18)',lc:'#ffc400'},
    {l:'PHYSICAL & DIGITAL LAYER',sub:'40+ Refineries · Pipelines · OT Devices · 250+ Apps · Multi-cloud · Digital Twin',       col:'rgba(255,23,68,.06)',str:'rgba(255,23,68,.16)',lc:'#ff1744'}
  ];
  const lh = (H-20)/(layers.length+.4);
  layers.forEach((lv,i)=>{
    const y=10+i*lh;
    rrect(ctx,10,y,W-20,lh-6,8); ctx.fillStyle=lv.col; ctx.fill(); ctx.strokeStyle=lv.str; ctx.lineWidth=.5; ctx.stroke();
    rrect(ctx,10,y,5,lh-6,2); ctx.fillStyle=lv.lc+'70'; ctx.fill();
    ctx.fillStyle='rgba(221,230,255,.85)'; ctx.font='700 12px Syne,sans-serif'; ctx.textAlign='left'; ctx.fillText(lv.l,24,y+21);
    ctx.fillStyle='rgba(122,144,187,.65)'; ctx.font='10px DM Sans,sans-serif'; ctx.fillText(lv.sub,24,y+38);
    if(i<layers.length-1){
      ctx.strokeStyle=lv.lc+'45'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(W/2,y+lh-6); ctx.lineTo(W/2,y+lh); ctx.stroke();
      ctx.fillStyle=lv.lc+'70'; ctx.font='10px monospace'; ctx.textAlign='center'; ctx.fillText('⬇',W/2-5,y+lh-1);
    }
  });
  ctx.fillStyle='rgba(0,229,255,.4)'; ctx.font='10px DM Sans,sans-serif'; ctx.textAlign='right'; ctx.fillText('↔ Real-time Kafka event bus',W-14,H-4);
}
