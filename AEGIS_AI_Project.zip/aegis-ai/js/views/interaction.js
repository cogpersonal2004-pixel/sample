/* js/views/interaction.js */
window.renderInteractionView = function () {
  const kafkaRows = window.AGENTS.map(a => `
    <div style="padding:7px 10px;background:var(--card2);border:1px solid var(--b1);border-left:2px solid ${a.color};border-radius:6px;margin-bottom:5px">
      <div style="font-size:11px;font-weight:600;margin-bottom:3px">${a.icon} ${a.name}</div>
      <div style="font-size:9px;color:var(--green);font-family:var(--mono)">PUB: ${a.kafkaPub}</div>
      <div style="font-size:9px;color:var(--cyan);font-family:var(--mono)">SUB: ${a.kafkaSub}</div>
    </div>`).join('');

  const collabItems = [
    {t:'Cyber → OT Agent',       d:'When lateral movement crosses IT/OT boundary, Cyber Agent pushes enriched graph to OT Agent for physical process verification.',c:'#ff1744'},
    {t:'Predictive → Self-Healing',d:'Pre-emptive trigger 4h before breach: Predictive Agent sends forecast, Self-Healing queues maintenance runbook automatically.',c:'#00e676'},
    {t:'Ticket → Self-Healing',   d:'Ticket Agent classifies resolution type; Self-Healing executes the fix and closes the ticket in a single autonomous cycle.',c:'#00e5ff'},
    {t:'Shadow IT → Compliance',  d:'Every unauthorized app discovery triggers immediate SOX compliance check and regulatory risk scoring by Compliance Agent.',c:'#d500f9'},
    {t:'All Agents → Compliance', d:'Every autonomous decision is published to aegis.compliance.audit. Compliance Agent logs, scores, and maintains 7-year immutable trail.',c:'#f50057'}
  ].map(p => `
    <div style="padding:8px 10px;background:var(--card2);border:1px solid var(--b1);border-left:2px solid ${p.c};border-radius:7px;margin-bottom:5px">
      <div style="font-size:11px;font-weight:600;margin-bottom:3px;color:${p.c}">${p.t}</div>
      <div style="font-size:10px;color:var(--text2);line-height:1.6">${p.d}</div>
    </div>`).join('');

  return /* html */`
    <div class="view-title">Agent Interaction Map</div>
    <div class="view-subtitle">How all 7 agents communicate with EOS Control Brain and each other via Kafka topics — complete data flow topology</div>
    <div class="card">
      <div class="card-hdr"><div class="card-title">Cross-Agent Communication Graph</div><span style="font-size:10px;color:var(--green)">● Live topology</span></div>
      <canvas id="interactionMap" width="860" height="480" style="width:100%;border-radius:8px"></canvas>
      <div class="map-legend">
        <div class="legend-item"><div class="legend-dot" style="background:var(--cyan)"></div>Data feed to EOS Brain</div>
        <div class="legend-item"><div class="legend-dot" style="background:var(--green)"></div>Autonomous action</div>
        <div class="legend-item"><div class="legend-dot" style="background:var(--amber)"></div>Cross-agent collaboration</div>
        <div class="legend-item"><div class="legend-dot" style="background:var(--red)"></div>Tier 1 escalation</div>
        <div class="legend-item"><div class="legend-dot" style="background:var(--purple)"></div>Compliance audit trigger</div>
      </div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-hdr"><div class="card-title">Agent Kafka Topic Mapping</div></div>${kafkaRows}</div>
      <div class="card"><div class="card-hdr"><div class="card-title">Cross-Agent Collaboration Patterns</div></div>${collabItems}</div>
    </div>`;
};
