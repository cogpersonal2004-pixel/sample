/* js/views/overview.js */
window.renderOverview = function () {
  return /* html */`
    <div class="view-actions">
      <div>
        <div class="view-title">EOS Control Brain</div>
        <div class="view-subtitle">Autonomous Enterprise AI Operations · BP Global Infrastructure · 40 Refineries · Multi-cloud AWS + Azure</div>
      </div>
      <div style="display:flex;gap:7px">
        <button class="btn btn-cyan"  onclick="App.runDemo()">▶ Run Incident Demo</button>
        <button class="btn btn-ghost" onclick="App.nav('scenario')">🎬 E2E Walkthrough</button>
        <button class="btn btn-ghost" onclick="App.nav('copilot')">💬 AI Copilot</button>
      </div>
    </div>

    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">62%</div><div class="metric-label">Ticket Auto-Resolution</div><div class="metric-delta up">▲ 18% vs baseline</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">1,847</div><div class="metric-label">Threats Neutralized (30d)</div><div class="metric-delta up">▲ 3 new today</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">94.7%</div><div class="metric-label">Predictive Accuracy MTTF</div><div class="metric-delta up">▲ 2.1% this week</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--red)">3</div><div class="metric-label">Active Tier 1 Incidents</div><div class="metric-delta down">▼ Human review required</div></div>
    </div>

    <div class="grid-2">
      <div class="card">
        <div class="card-hdr"><div class="card-title">🚨 Live Intelligence Feed</div><span style="font-size:9px;color:var(--text3);font-family:var(--mono)" id="feed-ts">live</span></div>
        <div id="alert-feed">
          <div class="alert-item"><div class="alert-dot crit"></div><div class="alert-body"><div class="alert-title">Lateral Movement Detected — Refinery SCADA Network</div><div class="alert-meta">Cyber Threat Agent · T−0:02:14 · Tier 1 · Confidence 97.3%</div></div><button class="alert-btn" onclick="App.nav('cyber')">Review</button></div>
          <div class="alert-item"><div class="alert-dot warn"></div><div class="alert-body"><div class="alert-title">Compressor Bearing Temp Trend — Khazzan Unit 7</div><div class="alert-meta">Predictive Agent · T−0:15:42 · Tier 2 · ETA failure: 6h</div></div><button class="alert-btn" onclick="App.nav('infra')">Forecast</button></div>
          <div class="alert-item"><div class="alert-dot warn"></div><div class="alert-body"><div class="alert-title">Unauthorized SaaS — 14 Identities Using Shadow Apps</div><div class="alert-meta">Shadow IT Agent · T−0:44:01 · Tier 2 · SOX risk flagged</div></div><button class="alert-btn">Remediate</button></div>
          <div class="alert-item"><div class="alert-dot ok"></div><div class="alert-body"><div class="alert-title">Auto-resolved: 34 repetitive VPN tickets</div><div class="alert-meta">Ticket + Self-Healing Agent · T−0:58:33 · Saved 8.5 engineer hours</div></div><button class="alert-btn">Audit Log</button></div>
          <div class="alert-item"><div class="alert-dot info"></div><div class="alert-body"><div class="alert-title">Digital Twin: Simulated Texas City overload scenario</div><div class="alert-meta">Predictive Agent · 847 simulations today · 7 real incidents prevented</div></div></div>
        </div>
      </div>
      <div class="card">
        <div class="card-hdr"><div class="card-title">⚡ Risk Matrix — Real-time</div><span class="tier-pill t1" style="font-size:9px">LIVE</span></div>
        <canvas id="riskCanvas" width="440" height="220" style="width:100%;border-radius:6px"></canvas>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:11px;text-align:center">
          <div><div style="font-size:22px;font-weight:700;color:var(--red);font-family:var(--mono)">3</div><div style="font-size:10px;color:var(--text3)">Tier 1 Active</div></div>
          <div><div style="font-size:22px;font-weight:700;color:var(--amber);font-family:var(--mono)">11</div><div style="font-size:10px;color:var(--text3)">Tier 2 Monitor</div></div>
          <div><div style="font-size:22px;font-weight:700;color:var(--cyan);font-family:var(--mono)">47</div><div style="font-size:10px;color:var(--text3)">Tier 3 Advisory</div></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-hdr"><div class="card-title">💰 Business Impact — Annualized ROI</div></div>
      <div class="roi-grid">
        <div class="roi-card"><div class="roi-value" style="color:var(--green)">$42M</div><div class="roi-label">IT Labor Savings<br>62% ticket reduction</div></div>
        <div class="roi-card"><div class="roi-value" style="color:var(--cyan)">$180M</div><div class="roi-label">Downtime Prevention<br>Predictive monitoring</div></div>
        <div class="roi-card"><div class="roi-value" style="color:var(--amber)">$95M</div><div class="roi-label">Breach Prevention<br>Cyber threat blocks</div></div>
        <div class="roi-card"><div class="roi-value" style="color:var(--teal)">$28M</div><div class="roi-label">Compliance Savings<br>SOX + EU AI Act</div></div>
        <div class="roi-card" style="background:rgba(0,229,255,.05);border-color:rgba(0,229,255,.18)"><div class="roi-value" style="color:var(--cyan)">$345M</div><div class="roi-label">Total Annual ROI<br>18-month payback</div></div>
      </div>
    </div>`;
};
