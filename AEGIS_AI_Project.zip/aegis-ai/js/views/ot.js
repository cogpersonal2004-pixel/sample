/* js/views/ot.js */
window.renderOTView = function () {
  const sites = [
    {name:'Texas City Refinery',   country:'USA',          status:'ok',   anom:0, scada:312},
    {name:'Khazzan Gas Field',     country:'Oman',         status:'warn', anom:1, scada:244},
    {name:'Castellón Refinery',    country:'Spain',        status:'ok',   anom:0, scada:198},
    {name:'Bulwer Island Terminal',country:'Australia',    status:'ok',   anom:0, scada:156},
    {name:'Ras Tanura Offtake',    country:'Saudi Arabia', status:'warn', anom:1, scada:289}
  ];

  const siteRows = sites.map(s => `
    <div class="info-row">
      <div style="display:flex;align-items:center;gap:9px">
        <div style="width:7px;height:7px;border-radius:50%;background:${s.status==='ok'?'var(--green)':'var(--amber)'};flex-shrink:0"></div>
        <div>
          <div class="info-row-title">${s.name} <span style="font-size:9px;color:var(--text3)">${s.country}</span></div>
          <div class="info-row-subtitle">${s.scada} SCADA points · ${s.anom} anomaly active</div>
        </div>
      </div>
      <span style="font-size:9px;padding:2px 8px;border-radius:4px;background:${s.anom?'rgba(255,196,0,.08)':'rgba(0,230,118,.06)'};color:${s.anom?'var(--amber)':'var(--green)'}">${s.anom?'MONITORING':'NOMINAL'}</span>
    </div>`).join('');

  return /* html */`
    <div class="view-title">🏭 OT Security Agent — Edge AI</div>
    <div class="view-subtitle">Ultra-low latency at refinery edge · IEC 62443 SL-3 compliant · Physical + cyber anomaly detection · 0.8ms decisions</div>
    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">0.8ms</div><div class="metric-label">Edge Decision Latency</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">40</div><div class="metric-label">Refinery Sites Online</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">12,400</div><div class="metric-label">SCADA Points Monitored</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--red)">2</div><div class="metric-label">OT Anomalies Active</div></div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-hdr"><div class="card-title">Refinery Network — Live SCADA Status</div></div>${siteRows}</div>
      <div class="card"><div class="card-hdr"><div class="card-title">Purdue Model — IT/OT Segmentation</div></div>
        <canvas id="purdueCanvas" width="420" height="260" style="width:100%"></canvas>
      </div>
    </div>`;
};
