/* js/views/scenario.js */
window.renderScenarioView = function () {
  const steps = window.SCENARIO_STEPS.map((s, i) => `
    <div class="scenario-step" id="step-${i}">
      <div class="step-num" id="stepnum-${i}">${i+1}</div>
      <div style="flex:1">
        <div class="step-title">${s.title}</div>
        <div class="step-desc">${s.desc}</div>
        <span class="step-agent-tag" style="background:${s.color}12;color:${s.color};border:1px solid ${s.color}25">${s.agent} · ${s.time}</span>
      </div>
    </div>`).join('');

  return /* html */`
    <div class="view-title">🎬 End-to-End Incident Walkthrough</div>
    <div class="view-subtitle">Real scenario: Zero-day exploit on pipeline SCADA → full response chain across all 7 agents + human gate</div>
    <div class="grid-2">
      <div class="card">
        <div class="card-hdr">
          <div class="card-title">Incident Timeline — Live Play</div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-cyan"  id="play-btn" onclick="Scenario.play()"  style="font-size:10px;padding:5px 12px">▶ Play</button>
            <button class="btn btn-ghost"               onclick="Scenario.reset()" style="font-size:10px;padding:5px 10px">↺ Reset</button>
          </div>
        </div>
        <div style="max-height:420px;overflow-y:auto">${steps}</div>
      </div>
      <div class="card">
        <div class="card-hdr"><div class="card-title">Cross-Agent Signal Correlation</div></div>
        <canvas id="signalCanvas" width="420" height="280" style="width:100%"></canvas>
        <div style="font-size:10px;color:var(--text2);margin-top:8px">EOS Brain correlates signals from Cyber, OT, and Compliance agents simultaneously to determine Tier 1 classification and containment action.</div>
      </div>
    </div>
    <div class="card">
      <div class="card-hdr"><div class="card-title">Agent Involvement Per Incident Phase</div></div>
      <canvas id="phaseCanvas" width="860" height="100" style="width:100%"></canvas>
    </div>`;
};

/* ── Scenario controller ── */
window.Scenario = (() => {
  let interval = null;
  let current  = -1;

  function activateStep(i) {
    document.querySelectorAll('.scenario-step').forEach((el, idx) => {
      el.classList.toggle('active', idx === i);
      el.classList.toggle('done',   idx <  i);
    });
    document.querySelectorAll('.step-num').forEach((el, idx) => {
      el.classList.toggle('active', idx === i);
      el.classList.toggle('done',   idx <  i);
    });
    const el = document.getElementById('step-' + i);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    drawSignalCanvas(i);
  }

  return {
    play() {
      this.reset();
      const btn = document.getElementById('play-btn');
      if (btn) btn.textContent = '⏸ Playing…';
      current = 0; activateStep(0);
      interval = setInterval(() => {
        current++;
        if (current >= window.SCENARIO_STEPS.length) {
          clearInterval(interval);
          const b = document.getElementById('play-btn'); if (b) b.textContent = '▶ Replay';
          return;
        }
        activateStep(current);
      }, 1600);
    },
    reset() {
      clearInterval(interval); current = -1;
      document.querySelectorAll('.scenario-step, .step-num').forEach(el => el.classList.remove('active','done'));
      const btn = document.getElementById('play-btn'); if (btn) btn.textContent = '▶ Play';
      drawSignalCanvas(-1);
    }
  };
})();
