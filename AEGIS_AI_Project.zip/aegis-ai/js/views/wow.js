/* js/views/wow.js */
window.renderWowView = function () {
  const wows = [
    { icon:'🧬', title:'Living Digital Twin',            color:'rgba(0,229,255,.12)',  tag:'INDUSTRY FIRST', tagCol:'var(--cyan)',   body:'The world\'s first AI-powered Digital Twin of an entire oil & gas enterprise. Virtual replica of 40 refineries, all networks, and 250+ apps. Runs 847 failure simulations daily. Predicts real-world incidents before they happen with 94.7% accuracy.' },
    { icon:'🕸️', title:'Graph Neural Network Threat Detection', color:'rgba(213,0,249,.1)',  tag:'BEYOND SPLUNK',  tagCol:'var(--purple)', body:'First enterprise SIEM to use GNN for entity relationship modeling. Detects lateral movement across IT/OT in 0.4ms. Catches zero-day threats with no prior signatures via VAE reconstruction error. 97.3% confidence, 0.3% FP rate.' },
    { icon:'🔄', title:'Reinforcement Learning Self-Healing', color:'rgba(0,230,118,.1)',  tag:'BEYOND SERVICENOW', tagCol:'var(--green)', body:'PPO RL agent learns optimal remediation sequences from every incident. Gets smarter after each fix. 99.2% success rate. Resolves in 23 seconds vs 4.1h human MTTR. Generates SAP work orders, Kubernetes rollbacks, and network reconfigurations autonomously.' },
    { icon:'⚡', title:'Cross-Domain Cognitive Reasoning',  color:'rgba(255,196,0,.1)',  tag:'MULTI-DOMAIN AI', tagCol:'var(--amber)',  body:'EOS Brain correlates signals across IT, OT, cybersecurity, compliance, and financial risk simultaneously. Detects hidden patterns no analyst could find — e.g. SCADA anomaly + unusual login + commodity spike → coordinated sabotage scenario.' },
    { icon:'🧠', title:'Persistent AI Memory (RAG)',        color:'rgba(255,109,0,.1)',  tag:'LEARNING SYSTEM',  tagCol:'var(--orange)', body:'Vector database stores 5 years of incidents, resolutions, and anomalies. Copilot retrieves relevant context in milliseconds. Resolution quality improves month over month. No other AIOps vendor has this full-lifecycle architecture.' },
    { icon:'🏭', title:'TinyML at Refinery Edge',           color:'rgba(29,233,182,.1)', tag:'EDGE-FIRST OT',    tagCol:'var(--teal)',   body:'ONNX-optimized models on NVIDIA Jetson at each refinery. No cloud round-trip. Decisions in 0.8ms. Works during network outages. Detects both physical process anomalies and cyber intrusions simultaneously at the sensor level.' }
  ];

  const wowCards = wows.map(w => `
    <div class="wow-card" style="background:var(--card)">
      <div style="position:absolute;top:0;right:0;width:80px;height:80px;background:radial-gradient(circle,${w.color},transparent 70%);pointer-events:none"></div>
      <div class="wow-icon">${w.icon}</div>
      <div class="wow-title">${w.title}</div>
      <div class="wow-body">${w.body}</div>
      <span class="wow-tag" style="background:${w.color};color:${w.tagCol};border:1px solid ${w.tagCol}44">${w.tag}</span>
    </div>`).join('');

  return /* html */`
    <div class="view-title">🚀 Innovation Highlights</div>
    <div class="view-subtitle">WOW factors that set AEGIS-AI apart from every existing AIOps solution including ServiceNow, Dynatrace, and Splunk SIEM</div>
    <div class="grid-3" style="margin-bottom:11px">${wowCards}</div>

    <div class="card">
      <div class="card-hdr"><div class="card-title">AEGIS-AI vs Competitors — Capability Comparison</div></div>
      <canvas id="compareChart" width="860" height="180" style="width:100%"></canvas>
    </div>

    <div class="card">
      <div class="card-hdr"><div class="card-title">Key Innovation Metrics</div></div>
      <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:9px">
        <div class="metric-cell"><div class="metric-value" style="color:var(--cyan);font-size:20px">0.4ms</div><div class="metric-label">Threat detection latency</div></div>
        <div class="metric-cell"><div class="metric-value" style="color:var(--green);font-size:20px">47s</div><div class="metric-label">Full incident response</div></div>
        <div class="metric-cell"><div class="metric-value" style="color:var(--purple);font-size:20px">0.3%</div><div class="metric-label">False positive rate</div></div>
        <div class="metric-cell"><div class="metric-value" style="color:var(--amber);font-size:20px">847</div><div class="metric-label">Twin simulations/day</div></div>
        <div class="metric-cell"><div class="metric-value" style="color:var(--teal);font-size:20px">5yr</div><div class="metric-label">RAG incident memory</div></div>
        <div class="metric-cell"><div class="metric-value" style="color:var(--orange);font-size:20px">18×</div><div class="metric-label">ROI vs competitors</div></div>
      </div>
    </div>`;
};
