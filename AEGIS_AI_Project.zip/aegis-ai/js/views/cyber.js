/* js/views/cyber.js */
window.renderCyberView = function () {
  return /* html */`
    <div class="view-title">🕸️ Cyber Threat Intelligence Agent</div>
    <div class="view-subtitle">Graph-based attack detection · Zero-day anomalies via VAE · Lateral movement · Insider threats · MITRE ATT&CK ICS v8</div>
    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--red)">3</div><div class="metric-label">Active APT Campaigns</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">97.3%</div><div class="metric-label">Detection Confidence</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">1,847</div><div class="metric-label">Threats Blocked (30d)</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">0.4ms</div><div class="metric-label">Detection Latency</div></div>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-hdr"><div class="card-title">Attack Kill Chain — Active Event</div><span class="tier-pill t1">LIVE INCIDENT</span></div>
        <canvas id="killchain" width="420" height="110" style="width:100%;margin-bottom:12px"></canvas>
        <div class="timeline">
          <div class="timeline-item"><div class="timeline-dot" style="background:var(--red)"></div><div class="timeline-time">04:20:17 UTC</div><div class="timeline-text"><strong>Initial Access:</strong> Phishing link clicked by contractor identity bp-ext-017. C2 beacon established.</div></div>
          <div class="timeline-item"><div class="timeline-dot" style="background:var(--red)"></div><div class="timeline-time">04:21:03 UTC</div><div class="timeline-text"><strong>Lateral Movement:</strong> GNN graph model detects anomalous credential reuse across 3 OT jump hosts (T1021.006)</div></div>
          <div class="timeline-item"><div class="timeline-dot" style="background:var(--amber)"></div><div class="timeline-time">04:22:14 UTC — NOW</div><div class="timeline-text"><strong>Containment:</strong> Zero Trust microsegmentation queued · Awaiting CISO approval (Tier 1 gate)</div></div>
        </div>
      </div>
      <div class="card">
        <div class="card-hdr"><div class="card-title">ML Detection Models</div></div>
        <div style="display:flex;flex-direction:column;gap:7px">
          <div class="stack-item"><div class="stack-title" style="display:flex;justify-content:space-between"><span>GNN Entity Graph (PyTorch Geometric)</span><span style="color:var(--green);font-size:9px">● LIVE</span></div><div class="stack-body">Lateral movement & insider threat via entity relationship graphs. Nodes: users, devices, processes. F1: 0.97</div><div style="background:var(--b1);border-radius:2px;height:3px;margin-top:6px;overflow:hidden"><div style="width:97%;height:100%;background:var(--green);border-radius:2px"></div></div></div>
          <div class="stack-item"><div class="stack-title" style="display:flex;justify-content:space-between"><span>Transformer UEBA</span><span style="color:var(--green);font-size:9px">● LIVE</span></div><div class="stack-body">Behavioral baselines per identity. Zero-day detection without prior signatures via anomaly scoring.</div><div style="background:var(--b1);border-radius:2px;height:3px;margin-top:6px;overflow:hidden"><div style="width:89%;height:100%;background:var(--cyan);border-radius:2px"></div></div></div>
          <div class="stack-item"><div class="stack-title" style="display:flex;justify-content:space-between"><span>VAE Anomaly Encoder (unsupervised)</span><span style="color:var(--green);font-size:9px">● LIVE</span></div><div class="stack-body">Reconstruction error for novel threats. No prior signatures needed. Detects OT-specific anomalies.</div><div style="background:var(--b1);border-radius:2px;height:3px;margin-top:6px;overflow:hidden"><div style="width:92%;height:100%;background:var(--purple);border-radius:2px"></div></div></div>
          <div class="stack-item"><div class="stack-title" style="display:flex;justify-content:space-between"><span>MITRE ATT&CK ICS Mapper</span><span style="color:var(--green);font-size:9px">● LIVE</span></div><div class="stack-body">Maps detected events to ATT&CK v14 Enterprise + ICS v8. Automatic TTP classification in real time.</div><div style="background:var(--b1);border-radius:2px;height:3px;margin-top:6px;overflow:hidden"><div style="width:100%;height:100%;background:var(--amber);border-radius:2px"></div></div></div>
        </div>
      </div>
    </div>`;
};
