/* js/views/copilot.js */
window.renderCopilotView = function () {
  return /* html */`
    <div class="view-title">💬 AI Copilot for Engineers</div>
    <div class="view-subtitle">Natural language interface · Ask anything about your infrastructure · Explainable AI decisions · RAG memory of 5 years of incidents</div>
    <div class="grid-2">
      <div>
        <div class="copilot-wrap">
          <div class="copilot-header">
            <div class="copilot-icon">⬡</div>
            <div>
              <div class="copilot-title">AEGIS Copilot</div>
              <div class="copilot-sub">Powered by EOS Brain · RAG memory · Full infrastructure context</div>
            </div>
            <div style="margin-left:auto;display:flex;align-items:center;gap:6px">
              <div class="pulse-dot"></div>
              <span style="font-size:10px;color:var(--green);font-family:var(--mono)">ONLINE</span>
            </div>
          </div>
          <div class="copilot-messages" id="cp-msgs">
            <div class="cp-msg ai">
              <div class="cp-avatar">⬡</div>
              <div class="cp-bubble">Hello! I'm AEGIS Copilot. I have full context of your BP infrastructure — 40 refineries, 250+ apps, live threat feeds, and 5 years of incident history. Ask me anything. Try a suggestion below.</div>
            </div>
          </div>
          <div class="copilot-suggestions">
            <div class="cp-suggestion" onclick="Copilot.ask('Why was server TX-PROD-047 restarted at 03:44 UTC?')">Why was TX-PROD-047 restarted?</div>
            <div class="cp-suggestion" onclick="Copilot.ask('What is the current cyber risk level?')">Current cyber risk level?</div>
            <div class="cp-suggestion" onclick="Copilot.ask('Which assets are predicted to fail in 24 hours?')">Assets failing in 24h?</div>
            <div class="cp-suggestion" onclick="Copilot.ask('Explain the lateral movement alert on SCADA network')">Explain SCADA lateral movement</div>
            <div class="cp-suggestion" onclick="Copilot.ask('Show me the SOX compliance status')">SOX compliance status?</div>
            <div class="cp-suggestion" onclick="Copilot.ask('What shadow IT tools are used by the trading team?')">Shadow IT — trading team?</div>
          </div>
          <div class="copilot-input-row">
            <input class="cp-input" id="cp-input" placeholder="Ask about any server, incident, threat or risk…" onkeydown="if(event.key==='Enter') Copilot.send()" />
            <button class="cp-send" onclick="Copilot.send()">Send ↗</button>
          </div>
        </div>
      </div>
      <div>
        <div class="card">
          <div class="card-hdr"><div class="card-title">Copilot Capabilities</div></div>
          <div style="display:flex;flex-direction:column;gap:7px">
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:2px solid var(--cyan)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">🔍 Root Cause Analysis</div><div style="font-size:10px;color:var(--text2)">Explains WHY any incident happened using full evidence chain from RAG memory of 5 years of incidents.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:2px solid var(--green)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">📊 Infrastructure Queries</div><div style="font-size:10px;color:var(--text2)">Real-time data from 250+ apps, 12,400 SCADA points, cloud metrics. Plain English queries.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:2px solid var(--amber)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">⚠️ Risk Briefings</div><div style="font-size:10px;color:var(--text2)">Instant risk summaries for any asset, site, or team. Tier classification with full justification.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:2px solid var(--purple)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">🎙️ Voice Interface</div><div style="font-size:10px;color:var(--text2)">Speak naturally to AEGIS: Whisper ASR → LLM reasoning → TTS response to engineers on-site.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:2px solid var(--teal)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">🧠 Explainable AI</div><div style="font-size:10px;color:var(--text2)">Every answer cites source data, model version, confidence score, and SHAP feature importance values.</div></div>
          </div>
        </div>
        <div class="card">
          <div class="card-hdr"><div class="card-title">Recent Queries</div></div>
          <div id="recent-queries"><div style="font-size:10px;color:var(--text3)">No queries yet — try asking something above</div></div>
        </div>
      </div>
    </div>`;
};

/* ── Copilot controller ── */
window.Copilot = (() => {
  const history = [];

  function appendMsg(role, html) {
    const msgs = document.getElementById('cp-msgs');
    if (!msgs) return;
    const d = document.createElement('div');
    d.className = `cp-msg ${role}`;
    d.innerHTML = role === 'user'
      ? `<div class="cp-avatar">U</div><div class="cp-bubble">${html}</div>`
      : `<div class="cp-avatar">⬡</div><div class="cp-bubble" style="font-family:var(--mono);font-size:10px;line-height:1.8">${html}</div>`;
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function updateRecent() {
    const el = document.getElementById('recent-queries'); if (!el) return;
    el.innerHTML = history.slice(0,5).map(q =>
      `<div style="padding:7px 10px;background:var(--card2);border:1px solid var(--b1);border-radius:6px;margin-bottom:5px">
        <div style="font-size:11px;margin-bottom:2px">${q.q}</div>
        <div style="font-size:9px;color:var(--text3);font-family:var(--mono)">${q.time}</div>
       </div>`).join('');
  }

  return {
    ask(q) {
      const inp = document.getElementById('cp-input');
      if (inp) inp.value = q;
      this.send();
    },
    send() {
      const inp = document.getElementById('cp-input'); if (!inp) return;
      const q = inp.value.trim(); if (!q) return;
      inp.value = '';
      appendMsg('user', q);

      /* Typing indicator */
      const msgs = document.getElementById('cp-msgs');
      const typing = document.createElement('div');
      typing.className = 'cp-msg ai'; typing.id = 'cp-typing';
      typing.innerHTML = `<div class="cp-avatar">⬡</div><div class="cp-bubble"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
      if (msgs) { msgs.appendChild(typing); msgs.scrollTop = msgs.scrollHeight; }

      history.unshift({ q, time: new Date().toLocaleTimeString() });

      setTimeout(() => {
        const t = document.getElementById('cp-typing'); if (t) t.remove();
        const resp = window.matchCopilotResponse(q).replace(/\n/g, '<br>');
        appendMsg('ai', resp);
        updateRecent();
      }, 1200);
    }
  };
})();
