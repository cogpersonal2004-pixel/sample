/* js/views/infra.js */
window.renderInfraView = function () {
  return /* html */`
    <div class="view-title">🔮 Predictive Infrastructure Brain</div>
    <div class="view-subtitle">Time-series forecasting · Interactive Digital Twin simulation · Failure prediction with 4.2h average lead time</div>
    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">94.7%</div><div class="metric-label">Prediction Accuracy</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">4.2h</div><div class="metric-label">Mean Lead Time (MTTF)</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">7</div><div class="metric-label">Failures Predicted (7d)</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--teal)">98.1%</div><div class="metric-label">Digital Twin Accuracy</div></div>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-hdr"><div class="card-title">Compressor Unit 7 — Bearing Temp Forecast</div><span class="tier-pill t2">FAILURE IN ~6h</span></div>
        <canvas id="tempForecast" width="420" height="155" style="width:100%"></canvas>
        <div style="margin-top:10px;padding:10px;background:rgba(255,196,0,.05);border:1px solid rgba(255,196,0,.18);border-radius:7px">
          <div style="font-size:11px;font-weight:600;color:var(--amber)">🔄 Self-Healing Agent — Action Queued</div>
          <div style="font-size:10px;color:var(--text2);margin-top:3px">SAP PM work order auto-generated · Maintenance team notified · Spare parts confirmed available</div>
        </div>
      </div>
      <div class="card">
        <div class="card-hdr"><div class="card-title">Digital Twin — Interactive Simulation</div><span style="font-size:9px;color:var(--green)">● Live Sync 98.1%</span></div>
        <canvas id="twinMap" width="420" height="180" style="width:100%"></canvas>
        <div style="margin-top:10px">
          <div style="font-size:10px;color:var(--text2);margin-bottom:7px">Simulate failure scenario:</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn btn-red"   onclick="simulateFailure('compressor')" style="font-size:10px;padding:5px 10px">⚡ Compressor Fail</button>
            <button class="btn btn-red"   onclick="simulateFailure('network')"    style="font-size:10px;padding:5px 10px">🌐 Network Outage</button>
            <button class="btn btn-red"   onclick="simulateFailure('scada')"      style="font-size:10px;padding:5px 10px">🏭 SCADA Overload</button>
            <button class="btn btn-cyan"  onclick="resetTwin()"                   style="font-size:10px;padding:5px 10px">↺ Reset Twin</button>
          </div>
          <div id="twin-result" style="margin-top:8px"></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-hdr"><div class="card-title">ML Models — Predictive Infrastructure Agent</div></div>
      <div class="grid-2">
        <div class="stack-item"><div class="stack-title">LSTM + Transformer Hybrid</div><div class="stack-body">Multivariate time-series across 12,400+ sensor streams. Seq2Seq with attention. NVIDIA Triton inference server.</div></div>
        <div class="stack-item"><div class="stack-title">Isolation Forest (Real-time)</div><div class="stack-body">Unsupervised anomaly detection on streaming sensor data. Sub-100ms inference via ONNX Runtime edge deployment.</div></div>
        <div class="stack-item"><div class="stack-title">GBM Survival Model (XGBoost)</div><div class="stack-body">MTTF prediction from historical sensor patterns. Trained on 5 years of equipment failure history across 40 sites.</div></div>
        <div class="stack-item"><div class="stack-title">Prophet + ARIMA Ensemble</div><div class="stack-body">Capacity planning and load forecasting. Handles refinery operational seasonality and planned maintenance windows.</div></div>
      </div>
    </div>`;
};
