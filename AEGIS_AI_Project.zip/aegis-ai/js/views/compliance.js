/* js/views/compliance.js */
window.renderComplianceView = function () {
  return /* html */`
    <div class="view-title">⚖️ Compliance & Risk Agent</div>
    <div class="view-subtitle">SOX · EU AI Act · IEC 62443 · NIST CSF 2.0 · Full immutable audit trail · SHAP explainability on every decision</div>
    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">98.4%</div><div class="metric-label">SOX Compliance Score</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">100%</div><div class="metric-label">EU AI Act Alignment</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">SL-3</div><div class="metric-label">IEC 62443 Level</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--teal)">847k</div><div class="metric-label">Audit Events (24h)</div></div>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-hdr"><div class="card-title">Regulatory Coverage Matrix</div></div>
        <div class="info-row"><div><div class="info-row-title">SOX Section 404</div><div class="info-row-subtitle">Financial controls & IT governance</div></div><div style="font-size:14px;font-weight:700;color:var(--green)">98.4%</div></div>
        <div class="info-row"><div><div class="info-row-title">EU AI Act (High-Risk)</div><div class="info-row-subtitle">Transparency, human oversight, explainability</div></div><div style="font-size:14px;font-weight:700;color:var(--green)">100%</div></div>
        <div class="info-row"><div><div class="info-row-title">IEC 62443 (OT Security)</div><div class="info-row-subtitle">Industrial control system cybersecurity</div></div><div style="font-size:14px;font-weight:700;color:var(--green)">SL-3</div></div>
        <div class="info-row"><div><div class="info-row-title">NIST CSF 2.0</div><div class="info-row-subtitle">Cybersecurity framework full alignment</div></div><div style="font-size:14px;font-weight:700;color:var(--green)">Tier 4</div></div>
        <div class="info-row"><div><div class="info-row-title">GDPR Article 22</div><div class="info-row-subtitle">Automated decision rights — under legal review</div></div><div style="font-size:14px;font-weight:700;color:var(--amber)">Review</div></div>
        <div style="margin-top:10px;padding:10px;background:rgba(0,229,255,.04);border:1px solid rgba(0,229,255,.15);border-radius:8px">
          <div style="font-size:10px;color:var(--cyan);font-weight:600;margin-bottom:5px">Copilot Audit Query Example</div>
          <div style="font-size:10px;color:var(--text2);font-style:italic">"Why was server TX-PROD-047 restarted at 03:44 UTC?"</div>
          <div style="font-size:10px;color:var(--text2);margin-top:4px">→ Self-Healing RL: Memory pressure 94% → OOM kill → Graceful restart in 23s → INC0081229 created. Confidence: 100%</div>
        </div>
      </div>
      <div class="card">
        <div class="card-hdr"><div class="card-title">Human-AI Decision Boundary</div></div>
        <canvas id="decisionBoundary" width="420" height="260" style="width:100%"></canvas>
      </div>
    </div>`;
};
