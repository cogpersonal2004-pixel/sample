/* js/views/tickets.js */
window.renderTicketsView = function () {
  const queue = [
    {t:'VPN timeout — 34 users',         a:'Auto-resolve → vpn-reconnect-v3',       c:'#00e676', time:'0.8m'},
    {t:'SAP login failure — Finance',     a:'Routing to SAP Basis + KB article',     c:'#00e5ff', time:'1.2m'},
    {t:'Laptop disk >90% — exec pool',    a:'Self-Healing: cleanup script deployed',  c:'#ffc400', time:'2.1m'},
    {t:'Azure AD password expiry x12',    a:'Auto-resolved: SSPR + bulk notify',      c:'#00e676', time:'0.4m'},
    {t:'SCADA cert expiry warning',       a:'Escalated: OT Agent + Tier 2 alert',     c:'#ff1744', time:'now'}
  ];

  const queueHTML = queue.map(t => `
    <div class="alert-item">
      <div class="alert-dot" style="background:${t.c}"></div>
      <div class="alert-body"><div class="alert-title">${t.t}</div><div class="alert-meta">${t.a}</div></div>
      <div style="font-size:9px;color:${t.c};font-family:var(--mono)">${t.time}</div>
    </div>`).join('');

  return /* html */`
    <div class="view-title">🧠 Ticket Intelligence Agent</div>
    <div class="view-subtitle">LLM semantic understanding · Auto-resolution learning system · 40,000+ tickets/month · 62% auto-resolved</div>
    <div class="metric-grid-4">
      <div class="metric-cell"><div class="metric-value" style="color:var(--green)">62%</div><div class="metric-label">Auto-Resolution Rate</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--cyan)">24,800</div><div class="metric-label">Tickets Resolved (30d)</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--amber)">3.2m</div><div class="metric-label">Mean Resolution Time</div></div>
      <div class="metric-cell"><div class="metric-value" style="color:var(--teal)">$42M</div><div class="metric-label">Annual Labor Savings</div></div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-hdr"><div class="card-title">Ticket Category Clustering (BERT + k-means)</div></div>
        <canvas id="clusterChart" width="420" height="200" style="width:100%"></canvas>
      </div>
      <div class="card"><div class="card-hdr"><div class="card-title">Live Ticket Processing Queue</div></div>${queueHTML}</div>
    </div>
    <div class="card">
      <div class="card-hdr"><div class="card-title">AI Resolution Pipeline</div></div>
      <canvas id="ticketFlow" width="860" height="76" style="width:100%"></canvas>
    </div>`;
};
