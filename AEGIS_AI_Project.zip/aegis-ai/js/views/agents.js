/* js/views/agents.js */
window.renderAgentsView = function () {
  const cards = window.AGENTS.map((a, i) => /* html */`
    <div class="agent-card" style="--agent-color:${a.color}" onclick="App.showAgentJSON(${i})">
      <div class="agent-header">
        <div class="agent-icon" style="background:${a.color}12;border:1px solid ${a.color}30">${a.icon}</div>
        <div style="flex:1">
          <div class="agent-name">${a.name}</div>
          <div class="agent-role">${a.role}</div>
        </div>
        <div style="width:7px;height:7px;border-radius:50%;background:${a.color};${a.id==='cyber'?'animation:blink .7s infinite':''}"></div>
      </div>
      <div style="font-size:9px;color:var(--text3);margin-bottom:3px">Models: <span style="color:var(--text2)">${a.models}</span></div>
      <div style="font-size:9px;color:var(--text3);margin-bottom:3px">Inputs: <span style="color:var(--text2)">${a.inputs}</span></div>
      <div style="font-size:9px;color:var(--text3);margin-bottom:7px">Interacts: <span style="color:${a.color}99">${a.interacts.join(' · ')}</span></div>
      <div class="agent-metrics">
        ${a.metrics.map(m => `<div class="agent-metric"><strong style="color:${a.color}">${m.value}</strong>${m.label}</div>`).join('')}
      </div>
    </div>`).join('');

  return /* html */`
    <div class="view-title">Cognitive Agent Network</div>
    <div class="view-subtitle">7 autonomous sub-agents · Dedicated ML stack per agent · Orchestrated by EOS Control Brain via Kafka event fabric</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px">${cards}</div>
    <div class="card" style="margin-top:11px">
      <div class="card-hdr">
        <div class="card-title">Live Agent Output Schema (JSON)</div>
        <span style="font-size:10px;color:var(--text2)">Click any agent card above ↑</span>
      </div>
      <div class="json-viewer" id="agent-json">
        <span class="json-comment">// Click an agent card to view its real-time output JSON schema</span>
      </div>
    </div>`;
};
