/* js/views/architecture.js */
window.renderArchitectureView = function () {
  return /* html */`
    <div class="view-title">🧱 System Architecture</div>
    <div class="view-subtitle">Layered: Perception → Intelligence → Action · Event-driven Kafka mesh · Zero Trust · Multi-cloud AWS + Azure</div>

    <div class="tab-bar">
      <div class="tab-btn active" onclick="Arch.switchTab('layers', this)">Architecture Layers</div>
      <div class="tab-btn"        onclick="Arch.switchTab('stack',  this)">Technology Stack</div>
      <div class="tab-btn"        onclick="Arch.switchTab('flow',   this)">Event-Driven Flow</div>
      <div class="tab-btn"        onclick="Arch.switchTab('sec',    this)">Zero Trust Security</div>
    </div>

    <div class="tab-panel active" id="arch-layers">
      <canvas id="archLayers" width="860" height="370" style="width:100%;border-radius:8px"></canvas>
    </div>

    <div class="tab-panel" id="arch-stack">
      <div class="grid-3">
        <div class="stack-item"><div class="stack-title">AI/ML Core</div><div class="stack-body">PyTorch 2.x · HuggingFace Transformers · LangGraph Agents · LlamaIndex RAG · MLflow · ONNX Runtime · Ray Distributed · Weights & Biases · NVIDIA Triton</div></div>
        <div class="stack-item"><div class="stack-title">Data & Streaming</div><div class="stack-body">Apache Kafka · Apache Flink CEP · Pinecone Vector DB · Delta Lake · Apache Spark · InfluxDB OT · AWS Kinesis · Azure Event Hub · Prometheus</div></div>
        <div class="stack-item"><div class="stack-title">Orchestration</div><div class="stack-body">Kubernetes + Istio · Terraform IaC · AWS EKS + Azure AKS · HashiCorp Vault · ArgoCD GitOps · Prometheus + Grafana · Jaeger · OpenTelemetry</div></div>
        <div class="stack-item"><div class="stack-title">IT/OT Integration</div><div class="stack-body">ServiceNow API · SAP S/4HANA · OSIsoft PI Historian · OPC-UA · MITRE ATT&CK ICS v8 · Azure Sentinel · CrowdStrike Falcon · Tenable OT · Claroty</div></div>
        <div class="stack-item"><div class="stack-title">Security & Governance</div><div class="stack-body">Zero Trust BeyondCorp · HashiCorp Vault · AWS IAM · Azure AD · Open Policy Agent · Sigstore · Evidently AI drift detection · SPIFFE identity · mTLS</div></div>
        <div class="stack-item"><div class="stack-title">AI Copilot Stack</div><div class="stack-body">GPT-4 fine-tuned + LangChain · Whisper ASR voice input · ElevenLabs TTS · LangSmith LLM tracing · SHAP explainability · RAG Pinecone · Guardrails AI</div></div>
      </div>
    </div>

    <div class="tab-panel" id="arch-flow">
      <canvas id="eventFlowCanvas" width="860" height="320" style="width:100%;border-radius:8px"></canvas>
      <div style="margin-top:10px;padding:11px;background:var(--card2);border-radius:7px;border:1px solid var(--b1);font-size:11px;color:var(--text2);line-height:1.7">
        All 7 agents subscribe/publish to dedicated Kafka topics. EOS Brain maintains a real-time decision graph — never a linear pipeline.
        Events are enriched with RAG context before agent processing. Cross-agent correlation runs in Apache Flink CEP at sub-second latency.
        Digital Twin receives every infrastructure event and runs parallel simulations continuously.
      </div>
    </div>

    <div class="tab-panel" id="arch-sec">
      <div class="grid-2">
        <div class="card">
          <div class="card-hdr"><div class="card-title">Zero Trust Principles</div></div>
          <div style="display:flex;flex-direction:column;gap:7px">
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:3px solid var(--green)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">Never Trust, Always Verify</div><div style="font-size:10px;color:var(--text2)">Every agent call authenticated via mTLS + SPIFFE identity federation. No implicit inter-service trust anywhere.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:3px solid var(--cyan)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">Least Privilege Access</div><div style="font-size:10px;color:var(--text2)">Each agent has scoped RBAC. OT Agent cannot write to IT systems. HashiCorp Vault dynamic secrets rotation.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:3px solid var(--amber)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">IT/OT Air Gap Enforcement</div><div style="font-size:10px;color:var(--text2)">Enforced at Purdue Level 3. Cross-boundary events require CISO approval chain. Data diode for Level 0.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:3px solid var(--purple)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">Model Governance & Drift Detection</div><div style="font-size:10px;color:var(--text2)">Evidently AI monitors all models. All updates need human sign-off in MLflow registry. Rollback in &lt;60 seconds.</div></div>
            <div style="padding:9px;background:var(--card2);border-radius:7px;border-left:3px solid var(--pink)"><div style="font-size:11px;font-weight:600;margin-bottom:3px">Immutable Audit Trail</div><div style="font-size:10px;color:var(--text2)">Every AI decision SHA-256 hash-verified. Azure Blob WORM storage. 7-year SOX retention. SHAP values logged per decision.</div></div>
          </div>
        </div>
        <div class="card">
          <div class="card-hdr"><div class="card-title">Human Override — Tier Decision Gates</div></div>
          <canvas id="tierGates" width="420" height="340" style="width:100%"></canvas>
        </div>
      </div>
    </div>`;
};

/* ── Architecture tab controller ── */
window.Arch = {
  switchTab(name, el) {
    document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    if (el) el.classList.add('active');
    document.getElementById('arch-' + name).classList.add('active');
    setTimeout(() => {
      if (name === 'layers') drawArchLayers();
      if (name === 'flow')   drawEventFlow();
      if (name === 'sec')    drawTierGates();
    }, 60);
  }
};
