/* ============================================================
   js/data/scenario-steps.js
   8-step end-to-end incident response scenario data.
   ============================================================ */

window.SCENARIO_STEPS = [
  {
    title: '🕸️ Cyber Agent detects anomalous login pattern',
    desc: 'Contractor bp-ext-017 accesses 3 OT jump hosts in 46 seconds. GNN entity graph scores relationship anomaly at 3.7σ. VAE reconstruction error spikes to 0.94.',
    agent: 'Cyber Threat Intelligence Agent',
    time: '04:20:17',
    color: '#ff1744'
  },
  {
    title: '📡 EOS Brain receives Tier 1 alert',
    desc: 'Cross-domain reasoning correlates Cyber Agent + OT Agent pressure anomaly + Compliance Agent SOX flag. Risk classified: TIER 1 — Safety-critical.',
    agent: 'EOS Control Brain (Master Agent)',
    time: '04:20:19',
    color: '#00e5ff'
  },
  {
    title: '🏭 OT Agent confirms physical process unchanged',
    desc: 'Edge AI at Texas City verifies no process deviation. Physical risk: SAFE. Cyber indicator: ACTIVE. Isolation can proceed without process disruption.',
    agent: 'OT Security Agent',
    time: '04:20:21',
    color: '#ffc400'
  },
  {
    title: '⚖️ Compliance Agent prepares audit record',
    desc: 'Logs all signals, model versions, confidence scores with SHAP values. Creates AUD-20241215-9991 with SHA-256 hash. EU AI Act compliance verified.',
    agent: 'Compliance & Risk Agent',
    time: '04:20:23',
    color: '#d500f9'
  },
  {
    title: '🔐 CISO notified — Human approval gate (Tier 1)',
    desc: 'EOS Brain halts autonomous action. PagerDuty alerts CISO with full evidence: attack path, confidence 97.3%, MITRE TTP T1021.006, recommended isolation scope.',
    agent: 'Human CISO + EOS Brain',
    time: '04:21:14',
    color: '#f50057'
  },
  {
    title: '✅ CISO approves microsegmentation',
    desc: 'CISO reviews AI recommendation in 47 seconds and approves. Zero Trust microsegmentation of affected SCADA subnet authorized. Approval logged immutably.',
    agent: 'Human CISO → EOS Brain',
    time: '04:22:01',
    color: '#00e676'
  },
  {
    title: '🔄 Self-Healing Agent executes containment',
    desc: 'PPO RL agent applies microsegmentation via Kubernetes network policy. Isolates 3 jump hosts. Revokes credentials bp-ext-017. Network blocked in 8 seconds.',
    agent: 'Self-Healing Automation Agent',
    time: '04:22:09',
    color: '#00e5ff'
  },
  {
    title: '🧠 Ticket Agent creates incident + notifies teams',
    desc: 'Auto-generates INC0091887 in ServiceNow. Notifies SOC, CISO, refinery ops. Attaches full AI investigation report. Compliance filed. RAG memory updated.',
    agent: 'Ticket Intelligence + Compliance Agent',
    time: '04:22:17',
    color: '#00bcd4'
  }
];
