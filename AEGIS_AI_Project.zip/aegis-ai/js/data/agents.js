/* ============================================================
   js/data/agents.js
   All 7 agent definitions: metadata, models, inputs,
   interactions, output JSON schema, and display metrics.
   ============================================================ */

window.AGENTS = [
  {
    id: 'ticket',
    icon: '🧠',
    name: 'Ticket Intelligence',
    role: 'Semantic auto-resolution engine',
    color: '#00bcd4',
    models: 'GPT-4 fine-tune · BERT clustering · t-SNE · RLHF',
    inputs: 'ServiceNow, Slack, email, CMDB',
    interacts: ['EOS Brain (results)', 'Self-Healing (trigger fix)', 'Compliance (SOX tickets)'],
    kafkaPub: 'aegis.tickets.resolved',
    kafkaSub: 'aegis.heal.trigger, aegis.compliance.audit',
    outputJSON: `{
  <span class="json-key">"ticket_id"</span>: <span class="json-string">"INC0081234"</span>,
  <span class="json-key">"category"</span>: <span class="json-string">"VPN_CONNECTIVITY"</span>,
  <span class="json-key">"resolution_confidence"</span>: <span class="json-number">0.94</span>,
  <span class="json-key">"action"</span>: <span class="json-string">"auto_resolve"</span>,
  <span class="json-key">"playbook"</span>: <span class="json-string">"vpn-reconnect-v3"</span>,
  <span class="json-key">"kb_article"</span>: <span class="json-string">"KB0041122"</span>,
  <span class="json-key">"resolution_secs"</span>: <span class="json-number">48</span>,
  <span class="json-key">"rl_reward_signal"</span>: <span class="json-number">0.91</span>
}`,
    metrics: [
      { label: 'Auto/day',  value: '823' },
      { label: 'Accuracy',  value: '96.1%' },
      { label: 'MTTR',      value: '3.2m' }
    ]
  },
  {
    id: 'predictive',
    icon: '🔮',
    name: 'Predictive Infrastructure',
    role: 'Failure prediction & digital twin',
    color: '#00e676',
    models: 'LSTM · Prophet · Isolation Forest · GBM Survival',
    inputs: 'Prometheus, SCADA, OSIsoft PI, APM',
    interacts: ['EOS Brain (predictions)', 'Self-Healing (pre-trigger)', 'OT Agent (sensor feed)', 'Compliance (SLA risk)'],
    kafkaPub: 'aegis.infra.prediction',
    kafkaSub: 'aegis.sensors.stream, aegis.heal.trigger',
    outputJSON: `{
  <span class="json-key">"asset_id"</span>: <span class="json-string">"COMP-KZ-007"</span>,
  <span class="json-key">"prediction"</span>: <span class="json-string">"BEARING_FAILURE"</span>,
  <span class="json-key">"confidence"</span>: <span class="json-number">0.89</span>,
  <span class="json-key">"eta_hours"</span>: <span class="json-number">6.2</span>,
  <span class="json-key">"severity"</span>: <span class="json-string">"TIER2"</span>,
  <span class="json-key">"twin_scenarios_run"</span>: <span class="json-number">47</span>,
  <span class="json-key">"work_order"</span>: <span class="json-string">"WO-SAP-8821447"</span>
}`,
    metrics: [
      { label: 'Accuracy',  value: '94.7%' },
      { label: 'Lead time', value: '4.2h' },
      { label: 'FP rate',   value: '<0.8%' }
    ]
  },
  {
    id: 'cyber',
    icon: '🕸️',
    name: 'Cyber Threat Intelligence',
    role: 'Graph-based attack detection',
    color: '#ff1744',
    models: 'GNN PyG · UEBA Transformer · VAE · MITRE mapper',
    inputs: 'SIEM, NDR, IAM logs, threat intel',
    interacts: ['EOS Brain (critical alerts)', 'OT Agent (IT/OT crossing)', 'Compliance (audit trigger)', 'Self-Healing (isolation)'],
    kafkaPub: 'aegis.cyber.threat, aegis.tier1.alert',
    kafkaSub: 'aegis.siem.stream, aegis.iam.events',
    outputJSON: `{
  <span class="json-key">"threat_id"</span>: <span class="json-string">"APT-2024-0847"</span>,
  <span class="json-key">"type"</span>: <span class="json-string">"LATERAL_MOVEMENT"</span>,
  <span class="json-key">"attack_path"</span>: [<span class="json-string">"bp-ext-017"</span>, <span class="json-string">"ot-jump-01"</span>],
  <span class="json-key">"mitre_ttp"</span>: <span class="json-string">"T1021.006"</span>,
  <span class="json-key">"confidence"</span>: <span class="json-number">0.973</span>,
  <span class="json-key">"tier"</span>: <span class="json-string">"TIER1"</span>,
  <span class="json-key">"action"</span>: <span class="json-string">"ISOLATE_PENDING_HUMAN"</span>
}`,
    metrics: [
      { label: 'Blocked/30d', value: '1,847' },
      { label: 'Latency',     value: '0.4ms' },
      { label: 'FP rate',     value: '0.3%' }
    ]
  },
  {
    id: 'ot',
    icon: '🏭',
    name: 'OT Security Agent',
    role: 'Edge AI for refinery OT/ICS',
    color: '#ffc400',
    models: 'TinyML Jetson · ONNX · PLC fingerprint CNN',
    inputs: 'SCADA/DCS, OPC-UA, PLCs, sensors',
    interacts: ['EOS Brain (OT events)', 'Cyber Agent (IT/OT crossing)', 'Predictive Agent (sensor data)', 'Compliance (IEC 62443)'],
    kafkaPub: 'aegis.ot.anomaly',
    kafkaSub: 'aegis.scada.stream, aegis.cyber.ot',
    outputJSON: `{
  <span class="json-key">"site"</span>: <span class="json-string">"REFINERY-TX-001"</span>,
  <span class="json-key">"alert_type"</span>: <span class="json-string">"PROCESS_ANOMALY"</span>,
  <span class="json-key">"equipment"</span>: <span class="json-string">"PRESSURE_RELIEF_VALVE"</span>,
  <span class="json-key">"deviation_sigma"</span>: <span class="json-number">3.4</span>,
  <span class="json-key">"physical_risk"</span>: <span class="json-string">"HIGH"</span>,
  <span class="json-key">"cyber_indicator"</span>: <span class="json-bool">false</span>,
  <span class="json-key">"latency_ms"</span>: <span class="json-number">0.8</span>
}`,
    metrics: [
      { label: 'Sites live', value: '40' },
      { label: 'Latency',    value: '0.8ms' },
      { label: 'SCADA pts',  value: '12,400' }
    ]
  },
  {
    id: 'shadow',
    icon: '🕵️',
    name: 'Shadow IT Discovery',
    role: 'Unauthorized SaaS/app detection',
    color: '#f50057',
    models: 'DNS NLP · App classifier · GBM risk scoring',
    inputs: 'DNS logs, proxy, OAuth tokens, DPI',
    interacts: ['EOS Brain (risk report)', 'Compliance Agent (SOX flag)', 'Ticket Agent (offboard tickets)'],
    kafkaPub: 'aegis.shadow.discovery',
    kafkaSub: 'aegis.dns.stream, aegis.proxy.log',
    outputJSON: `{
  <span class="json-key">"apps"</span>: [<span class="json-string">"Notion"</span>, <span class="json-string">"Figma"</span>, <span class="json-string">"Loom"</span>],
  <span class="json-key">"user_count"</span>: <span class="json-number">14</span>,
  <span class="json-key">"data_risk"</span>: <span class="json-string">"MEDIUM"</span>,
  <span class="json-key">"sox_risk"</span>: <span class="json-bool">true</span>,
  <span class="json-key">"action"</span>: <span class="json-string">"APPROVE_OR_OFFBOARD"</span>,
  <span class="json-key">"rationalization_score"</span>: <span class="json-number">0.71</span>
}`,
    metrics: [
      { label: 'Apps found',   value: '127' },
      { label: 'Risk flagged', value: '23' },
      { label: 'Rationalized', value: '89%' }
    ]
  },
  {
    id: 'compliance',
    icon: '⚖️',
    name: 'Compliance & Risk',
    role: 'SOX, EU AI Act, IEC 62443 guardian',
    color: '#d500f9',
    models: 'Policy NLP · risk scorer · audit classifier',
    inputs: 'All agent decisions, audit logs, regulations',
    interacts: ['ALL agents (receives every decision)', 'EOS Brain (risk classification)', 'Human CISO (Tier 1 gate)'],
    kafkaPub: 'aegis.compliance.audit',
    kafkaSub: 'aegis.ALL.decisions',
    outputJSON: `{
  <span class="json-key">"decision_id"</span>: <span class="json-string">"DEC-20241215-8821"</span>,
  <span class="json-key">"sox_compliant"</span>: <span class="json-bool">true</span>,
  <span class="json-key">"eu_ai_act_risk"</span>: <span class="json-string">"HIGH"</span>,
  <span class="json-key">"human_oversight"</span>: <span class="json-bool">true</span>,
  <span class="json-key">"audit_hash"</span>: <span class="json-string">"sha256:a4f8c2..."</span>,
  <span class="json-key">"retention_years"</span>: <span class="json-number">7</span>
}`,
    metrics: [
      { label: 'SOX score', value: '98.4%' },
      { label: 'Audit/day', value: '847k' },
      { label: 'Violations', value: '0' }
    ]
  },
  {
    id: 'selfheal',
    icon: '🔄',
    name: 'Self-Healing Automation',
    role: 'RL-powered autonomous remediation',
    color: '#00e5ff',
    models: 'PPO Reinforcement Learning · NLP2runbook · ITSM NLP',
    inputs: 'Monitoring alerts, predictive signals, CMDB',
    interacts: ['EOS Brain (action approval)', 'Ticket Agent (close tickets)', 'Predictive Agent (pre-trigger)', 'Compliance (audit actions)'],
    kafkaPub: 'aegis.heal.result',
    kafkaSub: 'aegis.alerts.stream, aegis.predict.pre',
    outputJSON: `{
  <span class="json-key">"action_id"</span>: <span class="json-string">"SH-20241215-1127"</span>,
  <span class="json-key">"trigger"</span>: <span class="json-string">"OOM_MEMORY_PRESSURE"</span>,
  <span class="json-key">"action_taken"</span>: <span class="json-string">"GRACEFUL_RESTART"</span>,
  <span class="json-key">"outcome"</span>: <span class="json-string">"SUCCESS"</span>,
  <span class="json-key">"resolve_secs"</span>: <span class="json-number">23</span>,
  <span class="json-key">"rl_reward"</span>: <span class="json-number">0.92</span>
}`,
    metrics: [
      { label: 'Actions/day', value: '340' },
      { label: 'Success',     value: '99.2%' },
      { label: 'MTTR saved',  value: '4.1h' }
    ]
  }
];
