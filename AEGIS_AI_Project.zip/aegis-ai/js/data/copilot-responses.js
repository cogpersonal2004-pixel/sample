/* ============================================================
   js/data/copilot-responses.js
   Pre-built AI Copilot response library keyed by intent.
   ============================================================ */

window.COPILOT_RESPONSES = {
  'tx-prod-047': `🔍 Root cause found in audit record AUD-20241215-8821:

• 03:44:12 UTC — Java process (sap-connector v3.2.1) consumed 94.2% memory
• OOM killer triggered, process terminated
• Self-Healing Agent detected via Prometheus alert rule OOM_PRESSURE
• Pre-checks passed: SAP backup verified, no active transactions
• Graceful restart executed in 23 seconds ✅
• Post-restart health check: PASSED
• ServiceNow ticket INC0081229 auto-created

Confidence: 100% | Model: Self-Healing RL v2.4
SHAP: memory_usage(0.94) → action(restart)`,

  'cyber risk': `⚠️ Current Enterprise Cybersecurity Risk: HIGH

🔴 TIER 1 ACTIVE:
• APT campaign targeting SCADA network (T1021.006)
• Lateral movement — 3 OT jump hosts compromised
• CISO approval pending for microsegmentation

🟡 TIER 2 MONITORING:
• 11 medium-risk anomalies across 5 sites
• Unusual credential patterns in Trading division

✅ MITIGATED TODAY:
• 1,847 threats blocked (30 days)
• 0.4ms mean detection latency
• All Tier 3 threats auto-resolved

Recommendation: Prioritize CISO approval within 15 minutes.`,

  'fail': `🔮 Predicted Failures — Next 24 Hours:

1. 🟠 COMP-KZ-007 (Khazzan Compressor Unit 7)
   Bearing failure · ETA: 6.2h · Confidence: 89%
   → SAP work order WO-8821447 queued

2. 🟡 PUMP-TX-014 (Texas City Feed Pump)
   Seal degradation · ETA: 18.4h · Confidence: 74%
   → Predictive maintenance scheduled

3. 🟡 NET-AZ-EASTUS-03 (Azure VNet Gateway)
   Throughput saturation · ETA: 21h · Confidence: 71%
   → Scale-out action pre-approved

All 3 have Self-Healing actions pre-queued. No Tier 1 risk.`,

  'lateral': `🕸️ Lateral Movement Analysis — APT-2024-0847:

Attack path reconstructed by GNN entity graph:
  bp-ext-017 (contractor laptop)
    → ot-jump-01 (OT jump server) — T+46s
    → ot-jump-02 (backup jump)   — T+89s
    → scada-ctrl-3 (SCADA controller) — BLOCKED

Indicators of Compromise:
• 3 jump hosts in 46 seconds (3.7σ anomaly)
• Credential reuse across 3 privileged accounts
• MITRE TTP: T1021.006 (Windows Remote Management)
• VAE reconstruction error: 0.94 (threshold: 0.7)

OT Process Status: SAFE
Recommended: Microsegment SCADA subnet + revoke bp-ext-017`,

  'sox': `⚖️ SOX Compliance Status — Current:

Overall Score: 98.4% ✅

Section 404 (IT Controls): 98.4%
• All AI decisions: immutable audit trails ✅
• Change management controls: ACTIVE ✅
• Access reviews: Completed 2024-12-01 ✅

🟡 1 Open Finding:
• 14 users with unauthorized SaaS (Notion, Figma)
• Shadow IT Agent flagged 2024-12-15
• Remediation deadline: 2024-12-22

Audit trail: 847,382 events (24h)
Retention: Azure Blob WORM — 7 years
Last external audit: Deloitte 2024-11-30 — CLEAN`,

  'shadow': `🕵️ Shadow IT — Trading Division:

14 users using unauthorized applications:

🔴 HIGH RISK:
• WhatsApp Web — 6 users — potential deal leak
• Telegram       — 3 users — encrypted comms risk

🟡 MEDIUM RISK:
• Notion — 8 users — unencrypted deal notes
• Loom   — 4 users — screen recording tool
• Figma  — 2 users — low risk, evaluate for approval

SOX Risk: HIGH — financial data in unsanctioned apps

Recommended Actions:
1. Block WhatsApp/Telegram at proxy (immediate)
2. Evaluate Notion for enterprise approval
3. Issue compliance training to 14 users
Ticket INC0089234 created for CISO review.`
};

/** Match a user query to a response key */
window.matchCopilotResponse = function (query) {
  const q = query.toLowerCase();
  for (const key of Object.keys(window.COPILOT_RESPONSES)) {
    if (q.includes(key)) return window.COPILOT_RESPONSES[key];
  }
  return `I searched the AEGIS-AI knowledge base for "${query}".\n\nNo active incidents match this exact query. All monitored assets in this domain are reporting normal telemetry. Historical RAG memory shows 0 similar incidents in the past 30 days.\n\nTry asking about: server restarts, cyber threats, predicted failures, lateral movement, SOX compliance, or shadow IT.`;
};
